/* Solaris-2 host system */

#include "hosts/sysv4.h"

#ifndef __GNUC__
/* get around a bug in the Sun C compiler */
#define const
#endif

/* That's all... */

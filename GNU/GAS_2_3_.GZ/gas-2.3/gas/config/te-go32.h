/*
 * This file is te-go32.h
 */

#define TE_GO32 1

#define LOCAL_LABELS_DOLLAR
#define LOCAL_LABELS_FB

#define TARGET_FORMAT "coff-go32"

/* these define interfaces */
#include "obj-format.h"

/* Remove leading underscore from the gcc generated symbol names */
#define STRIP_UNDERSCORE

/* end of te-sysv32.h */

#include "m68k/newsgas.h"

/* This is to be compatible with types.h.
   It was found to be necessary with Newsos 3.  */

#define SIZE_TYPE "long int"

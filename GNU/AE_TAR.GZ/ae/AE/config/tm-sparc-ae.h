/* AE program profiling system.
   tm- description file for a SPARC-based system with AE.
   Copyright (C) 1989, 1990 by James R. Larus (larus@cs.wisc.edu)

   AE and AEC are free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 1, or (at your option) any
   later version.

   AE and AEC are distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GNU CC; see the file COPYING.  If not, write to James R.
   Larus, Computer Sciences Department, University of Wisconsin--Madison,
   1210 West Dayton Street, Madison, WI 53706, USA or to the Free
   Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA. */


/* $Header: /var/home/larus/AE/AE/config/RCS/tm-sparc-ae.h,v 2.0 90/02/09 17:22:56 larus Exp Locker: larus $ */


#include "config/tm-sparc.h"

/* Add -AE flag: */

#undef CC1_SPEC
#define CC1_SPEC   "%{sun4:} \
		    %{AE}"


/* Link with the AE routines and start at _ae_start. */

#undef LINK_SPEC
#define LINK_SPEC "%{!e*:-e start} -dc -dp \
%{g:-Bstatic} %{static:-Bstatic} %{-Bstatic} \
%{AE:-e _ae_start -Bstatic}"

#undef LIB_SPEC

#define LIB_SPEC "%{a:/usr/lib/bb_link.o} \
%{AE:aecrt0.o%s} \
%{!p:%{!pg:-lc}}%{p:-lc_p}%{pg:-lc_p} "

#define AE

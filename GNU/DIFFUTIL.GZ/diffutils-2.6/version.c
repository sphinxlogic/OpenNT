/* Version number of GNU diff.  */

#include "config.h"

char const version_string[] = "2.6";

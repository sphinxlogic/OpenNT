
/*  A Bison parser, made from ./ldgram.y with Bison version GNU Bison version 1.22
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	INT	258
#define	NAME	259
#define	PLUSEQ	260
#define	MINUSEQ	261
#define	MULTEQ	262
#define	DIVEQ	263
#define	LSHIFTEQ	264
#define	RSHIFTEQ	265
#define	ANDEQ	266
#define	OREQ	267
#define	OROR	268
#define	ANDAND	269
#define	EQ	270
#define	NE	271
#define	LE	272
#define	GE	273
#define	LSHIFT	274
#define	RSHIFT	275
#define	UNARY	276
#define	END	277
#define	ALIGN_K	278
#define	BLOCK	279
#define	QUAD	280
#define	LONG	281
#define	SHORT	282
#define	BYTE	283
#define	SECTIONS	284
#define	SIZEOF_HEADERS	285
#define	OUTPUT_FORMAT	286
#define	FORCE_COMMON_ALLOCATION	287
#define	OUTPUT_ARCH	288
#define	INCLUDE	289
#define	MEMORY	290
#define	DEFSYMEND	291
#define	NOLOAD	292
#define	DSECT	293
#define	COPY	294
#define	INFO	295
#define	OVERLAY	296
#define	DEFINED	297
#define	TARGET_K	298
#define	SEARCH_DIR	299
#define	MAP	300
#define	ENTRY	301
#define	SIZEOF	302
#define	NEXT	303
#define	ADDR	304
#define	STARTUP	305
#define	HLL	306
#define	SYSLIB	307
#define	FLOAT	308
#define	NOFLOAT	309
#define	ORIGIN	310
#define	FILL	311
#define	LENGTH	312
#define	CREATE_OBJECT_SYMBOLS	313
#define	INPUT	314
#define	OUTPUT	315
#define	CONSTRUCTORS	316
#define	ALIGNMOD	317
#define	AT	318
#define	CHIP	319
#define	LIST	320
#define	SECT	321
#define	ABSOLUTE	322
#define	LOAD	323
#define	NEWLINE	324
#define	ENDWORD	325
#define	ORDER	326
#define	NAMEWORD	327
#define	FORMAT	328
#define	PUBLIC	329
#define	BASE	330
#define	ALIAS	331
#define	TRUNCATE	332
#define	REL	333
#define	INPUT_SCRIPT	334
#define	INPUT_MRI_SCRIPT	335
#define	INPUT_DEFSYM	336

#line 21 "./ldgram.y"

/*

 */

#define DONTDECLARE_MALLOC

#include "bfd.h"
#include "sysdep.h"
#include "bfdlink.h"
#include "ld.h"    
#include "ldexp.h"
#include "ldver.h"
#include "ldlang.h"
#include "ldemul.h"
#include "ldfile.h"
#include "ldmisc.h"
#include "ldmain.h"
#include "mri.h"
#include "ldlex.h"

#define YYDEBUG 1

static int typebits;

lang_memory_region_type *region;


char *current_file;
boolean ldgram_want_filename = true;
boolean had_script = false;
boolean force_make_executable = false;

boolean ldgram_in_script = false;
boolean ldgram_had_equals = false;


#define ERROR_NAME_MAX 20
static char *error_names[ERROR_NAME_MAX];
static int error_index;
#define PUSH_ERROR(x) if (error_index < ERROR_NAME_MAX) error_names[error_index] = x; error_index++;
#define POP_ERROR()   error_index--;

#line 64 "./ldgram.y"
typedef union {
  bfd_vma integer;
  char *name;
  int token;
  union etree_union *etree;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		352
#define	YYFLAG		-32768
#define	YYNTBASE	105

#define YYTRANSLATE(x) ((unsigned)(x) <= 336 ? yytranslate[x] : 165)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,   103,     2,     2,     2,    33,    20,     2,    36,
   100,    31,    29,    98,    30,     2,    32,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    15,    99,    23,
     9,    24,    14,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
   101,     2,   102,    19,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    44,    18,    45,   104,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,    10,    11,    12,    13,    16,    17,    21,
    22,    25,    26,    27,    28,    34,    35,    37,    38,    39,
    40,    41,    42,    43,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
    62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
    72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
    82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,    97
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     3,     6,     9,    11,    12,    17,    18,    21,    25,
    26,    29,    34,    36,    38,    41,    43,    48,    53,    57,
    60,    65,    69,    74,    79,    84,    87,    90,    93,    98,
   103,   106,   109,   110,   114,   117,   118,   120,   124,   126,
   130,   131,   134,   137,   138,   140,   142,   144,   146,   148,
   150,   152,   154,   159,   164,   169,   174,   179,   181,   186,
   191,   192,   198,   200,   204,   207,   212,   215,   218,   219,
   224,   227,   229,   233,   235,   236,   241,   242,   248,   249,
   255,   258,   260,   262,   264,   266,   271,   276,   279,   281,
   282,   284,   286,   288,   290,   292,   295,   296,   298,   300,
   302,   304,   306,   308,   310,   312,   314,   316,   320,   324,
   326,   327,   333,   336,   340,   341,   342,   350,   354,   358,
   362,   363,   368,   373,   377,   381,   383,   388,   392,   393,
   395,   397,   398,   401,   404,   408,   413,   416,   419,   422,
   426,   430,   434,   438,   442,   446,   450,   454,   458,   462,
   466,   470,   474,   478,   482,   486,   492,   496,   500,   505,
   507,   509,   514,   519,   524,   529,   531,   536,   537,   538,
   539,   540,   541,   542,   557,   559,   561,   563,   565,   567,
   568,   571,   577,   579,   584,   587
};

static const short yyrhs[] = {    95,
   116,     0,    96,   109,     0,    97,   107,     0,     4,     0,
     0,   108,     4,     9,   154,     0,     0,   110,   111,     0,
   111,   112,    85,     0,     0,    80,   154,     0,    80,   154,
    98,   154,     0,     4,     0,    81,     0,    87,   113,     0,
    86,     0,    90,     4,     9,   154,     0,    90,     4,    98,
   154,     0,    90,     4,   154,     0,    89,     4,     0,    82,
     4,    98,   154,     0,    82,     4,   154,     0,    82,     4,
     9,   154,     0,    37,     4,     9,   154,     0,    78,     4,
     9,   154,     0,    83,   115,     0,    84,   114,     0,    88,
     4,     0,    92,     4,    98,     4,     0,    92,     4,    98,
     3,     0,    91,   154,     0,    93,     3,     0,     0,   113,
    98,     4,     0,   113,     4,     0,     0,     4,     0,   114,
    98,     4,     0,     4,     0,   115,    98,     4,     0,     0,
   117,   118,     0,   118,   119,     0,     0,   139,     0,   122,
     0,   146,     0,   147,     0,   149,     0,   151,     0,   124,
     0,    99,     0,    59,    36,     4,   100,     0,    60,    36,
   106,   100,     0,    76,    36,   106,   100,     0,    47,    36,
     4,   100,     0,    49,    36,     4,   100,     0,    48,     0,
    75,    36,   121,   100,     0,    61,    36,   106,   100,     0,
     0,    50,   106,   120,   118,    35,     0,     4,     0,   121,
    98,     4,     0,   121,     4,     0,    43,    44,   123,    45,
     0,   123,   156,     0,   123,   124,     0,     0,    62,    36,
     4,   100,     0,   137,   136,     0,     4,     0,   125,   138,
     4,     0,     4,     0,     0,   101,   127,   125,   102,     0,
     0,     4,   128,    36,   125,   100,     0,     0,    31,   129,
    36,   125,   100,     0,   137,   136,     0,    74,     0,    99,
     0,    77,     0,   126,     0,   133,    36,   154,   100,     0,
    72,    36,   154,   100,     0,   131,   130,     0,   130,     0,
     0,   131,     0,    39,     0,    40,     0,    41,     0,    42,
     0,     9,   152,     0,     0,     5,     0,     6,     0,     7,
     0,     8,     0,    10,     0,    11,     0,    12,     0,    13,
     0,    99,     0,    98,     0,     4,     9,   152,     0,     4,
   135,   152,     0,    98,     0,     0,    51,    44,   141,   140,
    45,     0,   140,   141,     0,   140,    98,   141,     0,     0,
     0,     4,   142,   145,    15,   143,   138,   144,     0,    71,
     9,   152,     0,    73,     9,   152,     0,    36,     4,   100,
     0,     0,    66,    36,   106,   100,     0,    67,    36,   148,
   100,     0,    67,    36,   100,     0,   148,   138,   106,     0,
   106,     0,    68,    36,   150,   100,     0,   150,   138,   106,
     0,     0,    69,     0,    70,     0,     0,   153,   154,     0,
    30,   154,     0,    36,   154,   100,     0,    64,    36,   154,
   100,     0,   103,   154,     0,    29,   154,     0,   104,   154,
     0,   154,    31,   154,     0,   154,    32,   154,     0,   154,
    33,   154,     0,   154,    29,   154,     0,   154,    30,   154,
     0,   154,    27,   154,     0,   154,    28,   154,     0,   154,
    21,   154,     0,   154,    22,   154,     0,   154,    25,   154,
     0,   154,    26,   154,     0,   154,    23,   154,     0,   154,
    24,   154,     0,   154,    20,   154,     0,   154,    19,   154,
     0,   154,    18,   154,     0,   154,    14,   154,    15,   154,
     0,   154,    17,   154,     0,   154,    16,   154,     0,    58,
    36,     4,   100,     0,     3,     0,    46,     0,    63,    36,
     4,   100,     0,    65,    36,     4,   100,     0,    83,    36,
   154,   100,     0,    37,    36,   154,   100,     0,     4,     0,
    79,    36,   154,   100,     0,     0,     0,     0,     0,     0,
     0,     4,   157,   163,   155,   158,    44,   159,   132,    45,
   160,   164,   134,   161,   138,     0,    53,     0,    54,     0,
    55,     0,    56,     0,    57,     0,     0,   154,    15,     0,
   154,    36,   162,   100,    15,     0,    15,     0,    36,   162,
   100,    15,     0,    24,     4,     0,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   117,   119,   120,   124,   127,   129,   136,   141,   146,   148,
   151,   153,   154,   157,   160,   161,   162,   164,   166,   168,
   170,   172,   174,   176,   178,   180,   181,   182,   184,   186,
   188,   190,   192,   195,   197,   198,   201,   204,   207,   210,
   214,   219,   225,   227,   232,   234,   235,   236,   237,   238,
   239,   240,   241,   243,   245,   247,   249,   251,   253,   254,
   256,   257,   260,   264,   267,   272,   276,   278,   279,   282,
   285,   288,   291,   295,   300,   305,   306,   310,   311,   315,
   318,   320,   324,   325,   330,   331,   336,   346,   348,   351,
   353,   356,   359,   361,   363,   367,   375,   380,   383,   385,
   387,   389,   391,   393,   395,   400,   400,   404,   409,   418,
   419,   422,   426,   428,   429,   433,   435,   438,   444,   453,
   458,   462,   467,   469,   473,   476,   481,   483,   486,   489,
   492,   497,   499,   502,   505,   507,   509,   511,   513,   516,
   518,   520,   522,   524,   526,   528,   530,   532,   534,   536,
   538,   540,   542,   544,   546,   548,   550,   552,   554,   556,
   558,   561,   563,   565,   567,   569,   574,   576,   579,   581,
   583,   587,   587,   594,   596,   598,   599,   600,   601,   602,
   606,   608,   609,   610,   613,   616
};

static const char * const yytname[] = {   "$","error","$illegal.","INT","NAME",
"PLUSEQ","MINUSEQ","MULTEQ","DIVEQ","'='","LSHIFTEQ","RSHIFTEQ","ANDEQ","OREQ",
"'?'","':'","OROR","ANDAND","'|'","'^'","'&'","EQ","NE","'<'","'>'","LE","GE",
"LSHIFT","RSHIFT","'+'","'-'","'*'","'/'","'%'","UNARY","END","'('","ALIGN_K",
"BLOCK","QUAD","LONG","SHORT","BYTE","SECTIONS","'{'","'}'","SIZEOF_HEADERS",
"OUTPUT_FORMAT","FORCE_COMMON_ALLOCATION","OUTPUT_ARCH","INCLUDE","MEMORY","DEFSYMEND",
"NOLOAD","DSECT","COPY","INFO","OVERLAY","DEFINED","TARGET_K","SEARCH_DIR","MAP",
"ENTRY","SIZEOF","NEXT","ADDR","STARTUP","HLL","SYSLIB","FLOAT","NOFLOAT","ORIGIN",
"FILL","LENGTH","CREATE_OBJECT_SYMBOLS","INPUT","OUTPUT","CONSTRUCTORS","ALIGNMOD",
"AT","CHIP","LIST","SECT","ABSOLUTE","LOAD","NEWLINE","ENDWORD","ORDER","NAMEWORD",
"FORMAT","PUBLIC","BASE","ALIAS","TRUNCATE","REL","INPUT_SCRIPT","INPUT_MRI_SCRIPT",
"INPUT_DEFSYM","','","';'","')'","'['","']'","'!'","'~'","file","filename","defsym_expr",
"@1","mri_script_file","@2","mri_script_lines","mri_script_command","ordernamelist",
"mri_load_name_list","mri_abs_name_list","script_file","@3","ifile_list","ifile_p1",
"@4","input_list","sections","sec_or_group_p1","statement_anywhere","file_NAME_list",
"input_section_spec","@5","@6","@7","statement","statement_list","statement_list_opt",
"length","fill_opt","assign_op","end","assignment","opt_comma","memory","memory_spec_list",
"memory_spec","@8","origin_spec","length_spec","attributes_opt","startup","high_level_library",
"high_level_library_NAME_list","low_level_library","low_level_library_NAME_list",
"floating_point_support","mustbe_exp","@9","exp","opt_at","section","@10","@11",
"@12","@13","@14","type","opt_exp_with_type","memspec_opt",""
};
#endif

static const short yyr1[] = {     0,
   105,   105,   105,   106,   108,   107,   110,   109,   111,   111,
   112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
   112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
   112,   112,   112,   113,   113,   113,   114,   114,   115,   115,
   117,   116,   118,   118,   119,   119,   119,   119,   119,   119,
   119,   119,   119,   119,   119,   119,   119,   119,   119,   119,
   120,   119,   121,   121,   121,   122,   123,   123,   123,   124,
   124,   125,   125,   126,   127,   126,   128,   126,   129,   126,
   130,   130,   130,   130,   130,   130,   130,   131,   131,   132,
   132,   133,   133,   133,   133,   134,   134,   135,   135,   135,
   135,   135,   135,   135,   135,   136,   136,   137,   137,   138,
   138,   139,   140,   140,   140,   142,   141,   143,   144,   145,
   145,   146,   147,   147,   148,   148,   149,   150,   150,   151,
   151,   153,   152,   154,   154,   154,   154,   154,   154,   154,
   154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
   154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
   154,   154,   154,   154,   154,   154,   155,   155,   157,   158,
   159,   160,   161,   156,   162,   162,   162,   162,   162,   162,
   163,   163,   163,   163,   164,   164
};

static const short yyr2[] = {     0,
     2,     2,     2,     1,     0,     4,     0,     2,     3,     0,
     2,     4,     1,     1,     2,     1,     4,     4,     3,     2,
     4,     3,     4,     4,     4,     2,     2,     2,     4,     4,
     2,     2,     0,     3,     2,     0,     1,     3,     1,     3,
     0,     2,     2,     0,     1,     1,     1,     1,     1,     1,
     1,     1,     4,     4,     4,     4,     4,     1,     4,     4,
     0,     5,     1,     3,     2,     4,     2,     2,     0,     4,
     2,     1,     3,     1,     0,     4,     0,     5,     0,     5,
     2,     1,     1,     1,     1,     4,     4,     2,     1,     0,
     1,     1,     1,     1,     1,     2,     0,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     3,     3,     1,
     0,     5,     2,     3,     0,     0,     7,     3,     3,     3,
     0,     4,     4,     3,     3,     1,     4,     3,     0,     1,
     1,     0,     2,     2,     3,     4,     2,     2,     2,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     5,     3,     3,     4,     1,
     1,     4,     4,     4,     4,     1,     4,     0,     0,     0,
     0,     0,     0,    14,     1,     1,     1,     1,     1,     0,
     2,     5,     1,     4,     2,     0
};

static const short yydefact[] = {     0,
    41,     7,     5,     1,    44,     2,    10,     3,     0,    42,
     8,     0,     0,     0,     0,    58,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   130,   131,     0,     0,
    52,    43,    46,    51,     0,    45,    47,    48,    49,    50,
    13,     0,     0,     0,    14,     0,     0,     0,    16,    36,
     0,     0,     0,     0,     0,     0,     0,     0,    98,    99,
   100,   101,   132,   102,   103,   104,   105,   132,    69,     0,
     0,     4,    61,     0,     0,     0,     0,     0,     0,     0,
   129,     0,     0,   107,   106,    71,     0,     0,   160,   166,
     0,     0,     0,     0,   161,     0,     0,     0,     0,     0,
     0,     0,    11,     0,    39,    26,    37,    27,    15,    28,
    20,     0,    31,     0,    32,     9,     6,   108,     0,   109,
     0,     0,     0,    44,   116,   115,     0,     0,     0,     0,
     0,   124,   126,   111,   111,    63,     0,     0,     0,     0,
   138,   134,     0,     0,     0,     0,     0,     0,     0,   137,
   139,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    22,     0,     0,    35,     0,     0,     0,
    19,     0,   133,   169,    66,    68,    67,    56,    57,     0,
   121,     0,    53,    54,    60,    70,   122,   110,   123,     0,
   127,     0,    65,     0,    59,    55,    24,    25,   135,     0,
     0,     0,     0,     0,     0,     0,   158,   157,   155,   154,
   153,   147,   148,   151,   152,   149,   150,   145,   146,   143,
   144,   140,   141,   142,    12,    23,    21,    40,    38,    34,
    17,    18,    30,    29,     0,    62,     0,     0,   112,     0,
   113,   125,   128,    64,   165,   159,   162,   136,   163,   164,
     0,   183,   180,     0,   168,     0,     0,   114,   156,   175,
   176,   177,   178,   179,     0,   181,   180,     0,   170,   120,
     0,   111,     0,     0,     0,     0,   132,     0,   184,     0,
     0,   171,   118,     0,   117,   182,   167,    90,   132,    74,
    79,    92,    93,    94,    95,     0,    82,    84,    83,    75,
    85,    89,    91,     0,     0,     0,   119,     0,     0,     0,
     0,    88,   172,     0,    81,     0,     0,     0,    72,   111,
   186,     0,   111,   111,    87,    76,     0,     0,    97,    86,
    78,    80,    73,   185,   132,   173,    96,   111,   174,     0,
     0,     0
};

static const short yydefgoto[] = {   350,
    73,     8,     9,     6,     7,    11,    57,   109,   108,   106,
     4,     5,    10,    32,   124,   137,    33,   121,    34,   330,
   311,   321,   318,   319,   312,   313,   314,   315,   346,    68,
    86,    35,   337,    36,   192,   126,   191,   282,   295,   248,
    37,    38,   134,    39,   135,    40,   118,   119,   143,   279,
   187,   245,   286,   298,   331,   348,   275,   265,   339
};

static const short yypact[] = {   -34,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    12,   322,
     1,    10,   289,    20,    37,-32768,    97,    42,    96,   105,
   106,   109,   110,   111,   112,   122,-32768,-32768,   123,   124,
-32768,-32768,-32768,-32768,   -69,-32768,-32768,-32768,-32768,-32768,
-32768,    52,   157,   224,-32768,   158,   161,   162,-32768,-32768,
   163,   164,   167,   224,   168,   171,    90,   224,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   174,
   175,-32768,-32768,   183,   184,    42,    42,   185,    42,     2,
-32768,   189,    42,-32768,-32768,-32768,   186,   187,-32768,-32768,
   224,   224,   224,   166,-32768,   170,   172,   173,   176,   179,
   224,   224,   531,   140,-32768,    99,-32768,   101,    40,-32768,
-32768,   210,   636,   102,-32768,-32768,   636,-32768,   224,-32768,
    14,    94,   107,-32768,-32768,-32768,   118,   121,   126,   129,
   133,-32768,-32768,   -48,   -45,-32768,    39,   134,   224,   224,
-32768,-32768,   385,   224,   207,   218,   224,   231,   224,-32768,
-32768,   224,   224,   224,   224,   224,   224,   224,   224,   224,
   224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
   224,   224,   224,   636,   233,   238,-32768,   241,   224,   224,
   636,    63,   636,   289,-32768,-32768,-32768,-32768,-32768,   286,
   212,     9,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    42,
-32768,    42,-32768,   245,-32768,-32768,   636,   636,-32768,   406,
   152,   155,   426,   159,   446,   616,   577,   594,   651,   665,
   678,   689,   689,   311,   311,   311,   311,     4,     4,    38,
    38,-32768,-32768,-32768,   636,   636,   636,-32768,-32768,-32768,
   636,   636,-32768,-32768,   221,-32768,   258,   248,-32768,   183,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   224,-32768,   127,   557,   190,   165,   193,-32768,   636,-32768,
-32768,-32768,-32768,-32768,   177,-32768,    98,   230,-32768,-32768,
   262,   194,   257,   181,   224,   239,-32768,   232,-32768,   276,
   470,-32768,-32768,   294,-32768,-32768,-32768,     0,-32768,    15,
-32768,-32768,-32768,-32768,-32768,   270,-32768,-32768,-32768,-32768,
-32768,-32768,     0,   264,   274,   -69,-32768,   275,   279,   224,
   308,-32768,-32768,   224,-32768,   308,   308,   491,-32768,   -53,
   292,   511,   -20,     6,-32768,-32768,   313,   314,   310,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   194,-32768,   320,
   323,-32768
};

static const short yypgoto[] = {-32768,
   -68,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,   198,-32768,-32768,-32768,-32768,-32768,   209,  -229,
-32768,-32768,-32768,-32768,    18,-32768,-32768,-32768,-32768,-32768,
    16,  -281,  -132,-32768,-32768,  -185,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -67,-32768,   -44,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,    72,-32768,-32768
};


#define	YYLAST		722


static const short yytable[] = {   103,
   120,   200,   202,   300,    41,    72,   251,   128,   129,   113,
   131,   133,   125,   117,   138,    12,   316,   184,    58,    59,
    60,    61,    62,    63,    64,    65,    66,    67,    84,    85,
   301,   316,   166,   167,   168,   169,   170,    42,   302,   303,
   304,   305,   203,   177,   198,    72,   141,   142,   336,   198,
   -77,   199,   198,   249,   201,    87,   150,   151,   185,   174,
     1,     2,     3,    69,   268,   243,   244,   181,   168,   169,
   170,   306,    70,   307,   183,    23,   308,   198,    43,   341,
    44,    45,    46,    47,    48,   -33,    49,    50,    51,    52,
    53,    54,    55,    56,   207,   208,   333,   334,   309,   210,
   310,   132,   213,   198,   215,   342,   250,   216,   217,   218,
   219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
   229,   230,   231,   232,   233,   234,   235,   236,   237,    89,
    90,   252,    71,   253,   241,   242,   204,   178,   205,    74,
    75,    76,    89,    90,    77,    78,    79,    80,   172,   288,
   270,   271,   272,   273,   274,    91,    92,    81,    82,    83,
    88,   104,    93,    94,   105,   107,   110,   111,    91,    92,
   112,   114,    95,   115,   116,    93,    94,   122,   123,   270,
   271,   272,   273,   274,    96,    95,   125,   127,   130,    97,
    98,    99,   136,   188,   139,   140,   175,    96,   176,   182,
   264,   144,    97,    98,    99,   145,   189,   146,   147,   100,
   211,   148,    89,    90,   149,   349,   269,   193,   179,   293,
   194,   212,   100,    89,    90,   195,    89,    90,   196,   101,
   102,   317,   197,   206,   214,   262,   238,   173,    91,    92,
   291,   239,   101,   102,   240,    93,    94,   247,   254,    91,
    92,   256,    91,    92,   257,    95,   263,    94,   259,    93,
    94,   266,   267,   281,   280,   285,    95,    96,   278,    95,
   287,   289,    97,    98,    99,   328,   283,   347,    96,   332,
   290,    96,   292,    97,    98,    99,    97,    98,    99,    13,
   296,   198,   100,    59,    60,    61,    62,    63,    64,    65,
    66,    67,   299,   100,   294,   320,   100,   180,   323,   324,
   326,   329,   101,   102,   327,   338,   343,   344,   345,   351,
   246,   190,   352,   101,   102,    13,   101,   102,    14,   186,
   322,   325,    15,    16,    17,    18,    19,   164,   165,   166,
   167,   168,   169,   170,    20,    21,    22,    23,   284,     0,
     0,    24,    25,    26,    27,    28,     0,     0,     0,     0,
    29,    30,     0,     0,    14,     0,     0,     0,    15,    16,
    17,    18,    19,     0,     0,     0,     0,     0,     0,     0,
    20,    21,    22,    23,    31,     0,     0,    24,    25,    26,
    27,    28,     0,     0,     0,     0,    29,    30,   152,     0,
   153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,     0,   152,
    31,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,   152,
     0,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,   152,
     0,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,     0,
     0,     0,     0,   152,   209,   153,   154,   155,   156,   157,
   158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   168,   169,   170,     0,   152,   255,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   152,   258,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   152,   260,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,     0,     0,     0,     0,     0,   297,
   152,   276,   153,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   335,     0,   277,   154,   155,   156,   157,   158,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
   340,   155,   156,   157,   158,   159,   160,   161,   162,   163,
   164,   165,   166,   167,   168,   169,   170,     0,   171,   152,
   261,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,   152,
     0,   153,   154,   155,   156,   157,   158,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   168,   169,   170,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   169,   170,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   158,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
   170,   160,   161,   162,   163,   164,   165,   166,   167,   168,
   169,   170
};

static const short yycheck[] = {    44,
    68,   134,   135,     4,     4,     4,   192,    76,    77,    54,
    79,    80,     4,    58,    83,     4,   298,     4,     9,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    98,    99,
    31,   313,    29,    30,    31,    32,    33,    37,    39,    40,
    41,    42,     4,     4,    98,     4,    91,    92,   102,    98,
    36,   100,    98,    45,   100,     4,   101,   102,    45,   104,
    95,    96,    97,    44,   250,     3,     4,   112,    31,    32,
    33,    72,    36,    74,   119,    62,    77,    98,    78,   100,
    80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
    90,    91,    92,    93,   139,   140,   326,   327,    99,   144,
   101,   100,   147,    98,   149,   100,    98,   152,   153,   154,
   155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
   165,   166,   167,   168,   169,   170,   171,   172,   173,     3,
     4,   200,    36,   202,   179,   180,    98,    98,   100,    44,
    36,    36,     3,     4,    36,    36,    36,    36,     9,   282,
    53,    54,    55,    56,    57,    29,    30,    36,    36,    36,
     4,     4,    36,    37,     4,     4,     4,     4,    29,    30,
     4,     4,    46,     3,    85,    36,    37,     4,     4,    53,
    54,    55,    56,    57,    58,    46,     4,     4,     4,    63,
    64,    65,     4,   100,     9,     9,    98,    58,    98,    98,
   245,    36,    63,    64,    65,    36,   100,    36,    36,    83,
     4,    36,     3,     4,    36,   348,   261,   100,     9,   287,
   100,     4,    83,     3,     4,   100,     3,     4,   100,   103,
   104,   299,   100,   100,     4,    15,     4,    98,    29,    30,
   285,     4,   103,   104,     4,    36,    37,    36,     4,    29,
    30,   100,    29,    30,   100,    46,    36,    37,   100,    36,
    37,     4,    15,    71,   100,    36,    46,    58,    79,    46,
     9,    15,    63,    64,    65,   320,   100,   345,    58,   324,
   100,    58,    44,    63,    64,    65,    63,    64,    65,     4,
    15,    98,    83,     5,     6,     7,     8,     9,    10,    11,
    12,    13,     9,    83,    73,    36,    83,    98,    45,    36,
    36,     4,   103,   104,    36,    24,     4,     4,     9,     0,
    35,   124,     0,   103,   104,     4,   103,   104,    43,   121,
   313,   316,    47,    48,    49,    50,    51,    27,    28,    29,
    30,    31,    32,    33,    59,    60,    61,    62,   277,    -1,
    -1,    66,    67,    68,    69,    70,    -1,    -1,    -1,    -1,
    75,    76,    -1,    -1,    43,    -1,    -1,    -1,    47,    48,
    49,    50,    51,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    59,    60,    61,    62,    99,    -1,    -1,    66,    67,    68,
    69,    70,    -1,    -1,    -1,    -1,    75,    76,    14,    -1,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    -1,    14,
    99,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    14,
    -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    14,
    -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    -1,
    -1,    -1,    -1,    14,   100,    16,    17,    18,    19,    20,
    21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
    31,    32,    33,    -1,    14,   100,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,    32,    33,    14,   100,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,    32,    33,    14,   100,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,    32,    33,    -1,    -1,    -1,    -1,    -1,   100,
    14,    15,    16,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
   100,    -1,    36,    17,    18,    19,    20,    21,    22,    23,
    24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
   100,    18,    19,    20,    21,    22,    23,    24,    25,    26,
    27,    28,    29,    30,    31,    32,    33,    -1,    98,    14,
    15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    14,
    -1,    16,    17,    18,    19,    20,    21,    22,    23,    24,
    25,    26,    27,    28,    29,    30,    31,    32,    33,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,    32,    33,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    21,    22,
    23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
    33,    23,    24,    25,    26,    27,    28,    29,    30,    31,
    32,    33
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/unsupported/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/unsupported/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 5:
#line 128 "./ldgram.y"
{ ldlex_defsym(); ;
    break;}
case 6:
#line 130 "./ldgram.y"
{
		  ldlex_popstate();
		  lang_add_assignment(exp_assop(yyvsp[-1].token,yyvsp[-2].name,yyvsp[0].etree));
		;
    break;}
case 7:
#line 137 "./ldgram.y"
{    	ldlex_mri_script();
			PUSH_ERROR("MRI style script");
		;
    break;}
case 8:
#line 141 "./ldgram.y"
{	ldlex_popstate(); 
			POP_ERROR();
		;
    break;}
case 13:
#line 154 "./ldgram.y"
{
			einfo("%P%F: unrecognised keyword in MRI style script '%s'\n",yyvsp[0].name);
			;
    break;}
case 14:
#line 157 "./ldgram.y"
{
			config.map_filename = "-";
			;
    break;}
case 17:
#line 163 "./ldgram.y"
{ mri_public(yyvsp[-2].name, yyvsp[0].etree); ;
    break;}
case 18:
#line 165 "./ldgram.y"
{ mri_public(yyvsp[-2].name, yyvsp[0].etree); ;
    break;}
case 19:
#line 167 "./ldgram.y"
{ mri_public(yyvsp[-1].name, yyvsp[0].etree); ;
    break;}
case 20:
#line 169 "./ldgram.y"
{ mri_format(yyvsp[0].name); ;
    break;}
case 21:
#line 171 "./ldgram.y"
{ mri_output_section(yyvsp[-2].name, yyvsp[0].etree);;
    break;}
case 22:
#line 173 "./ldgram.y"
{ mri_output_section(yyvsp[-1].name, yyvsp[0].etree);;
    break;}
case 23:
#line 175 "./ldgram.y"
{ mri_output_section(yyvsp[-2].name, yyvsp[0].etree);;
    break;}
case 24:
#line 177 "./ldgram.y"
{ mri_align(yyvsp[-2].name,yyvsp[0].etree); ;
    break;}
case 25:
#line 179 "./ldgram.y"
{ mri_alignmod(yyvsp[-2].name,yyvsp[0].etree); ;
    break;}
case 28:
#line 183 "./ldgram.y"
{ mri_name(yyvsp[0].name); ;
    break;}
case 29:
#line 185 "./ldgram.y"
{ mri_alias(yyvsp[-2].name,yyvsp[0].name,0);;
    break;}
case 30:
#line 187 "./ldgram.y"
{ mri_alias(yyvsp[-2].name,0,(int) yyvsp[0].integer);;
    break;}
case 31:
#line 189 "./ldgram.y"
{ mri_base(yyvsp[0].etree); ;
    break;}
case 32:
#line 191 "./ldgram.y"
{  mri_truncate((unsigned int) yyvsp[0].integer); ;
    break;}
case 34:
#line 196 "./ldgram.y"
{ mri_order(yyvsp[0].name); ;
    break;}
case 35:
#line 197 "./ldgram.y"
{ mri_order(yyvsp[0].name); ;
    break;}
case 37:
#line 203 "./ldgram.y"
{ mri_load(yyvsp[0].name); ;
    break;}
case 38:
#line 204 "./ldgram.y"
{ mri_load(yyvsp[0].name); ;
    break;}
case 39:
#line 209 "./ldgram.y"
{ mri_only_load(yyvsp[0].name); ;
    break;}
case 40:
#line 211 "./ldgram.y"
{ mri_only_load(yyvsp[0].name); ;
    break;}
case 41:
#line 215 "./ldgram.y"
{
	 ldlex_both();
	;
    break;}
case 42:
#line 219 "./ldgram.y"
{
	ldlex_popstate();
	;
    break;}
case 53:
#line 242 "./ldgram.y"
{ lang_add_target(yyvsp[-1].name); ;
    break;}
case 54:
#line 244 "./ldgram.y"
{ ldfile_add_library_path(yyvsp[-1].name); ;
    break;}
case 55:
#line 246 "./ldgram.y"
{ lang_add_output(yyvsp[-1].name, 1); ;
    break;}
case 56:
#line 248 "./ldgram.y"
{ lang_add_output_format(yyvsp[-1].name, 1); ;
    break;}
case 57:
#line 250 "./ldgram.y"
{ ldfile_set_output_arch(yyvsp[-1].name); ;
    break;}
case 58:
#line 252 "./ldgram.y"
{ command_line.force_common_definition = true ; ;
    break;}
case 60:
#line 255 "./ldgram.y"
{ lang_add_map(yyvsp[-1].name); ;
    break;}
case 61:
#line 257 "./ldgram.y"
{ ldfile_open_command_file(yyvsp[0].name); ;
    break;}
case 63:
#line 262 "./ldgram.y"
{ lang_add_input_file(yyvsp[0].name,lang_input_file_is_search_file_enum,
				 (char *)NULL); ;
    break;}
case 64:
#line 265 "./ldgram.y"
{ lang_add_input_file(yyvsp[0].name,lang_input_file_is_search_file_enum,
				 (char *)NULL); ;
    break;}
case 65:
#line 268 "./ldgram.y"
{ lang_add_input_file(yyvsp[0].name,lang_input_file_is_search_file_enum,
				 (char *)NULL); ;
    break;}
case 70:
#line 284 "./ldgram.y"
{ lang_add_entry(yyvsp[-1].name); ;
    break;}
case 72:
#line 290 "./ldgram.y"
{ lang_add_wild(yyvsp[0].name, current_file); ;
    break;}
case 73:
#line 292 "./ldgram.y"
{ lang_add_wild(yyvsp[0].name, current_file); ;
    break;}
case 74:
#line 297 "./ldgram.y"
{
		lang_add_wild((char *)NULL, yyvsp[0].name);
		;
    break;}
case 75:
#line 301 "./ldgram.y"
{
			current_file = (char *)NULL;
			;
    break;}
case 77:
#line 307 "./ldgram.y"
{
			current_file =yyvsp[0].name;
			;
    break;}
case 79:
#line 312 "./ldgram.y"
{
			current_file = (char *)NULL;
			;
    break;}
case 82:
#line 321 "./ldgram.y"
{
 		lang_add_attribute(lang_object_symbols_statement_enum); 
	      	;
    break;}
case 84:
#line 326 "./ldgram.y"
{
 		
		  lang_add_attribute(lang_constructors_statement_enum); 
		;
    break;}
case 86:
#line 332 "./ldgram.y"
{
			lang_add_data((int) yyvsp[-3].integer,yyvsp[-1].etree);
			;
    break;}
case 87:
#line 337 "./ldgram.y"
{
			  lang_add_fill
			    (exp_get_value_int(yyvsp[-1].etree,
					       0,
					       "fill value",
					       lang_first_phase_enum));
			;
    break;}
case 92:
#line 358 "./ldgram.y"
{ yyval.integer = yyvsp[0].token; ;
    break;}
case 93:
#line 360 "./ldgram.y"
{ yyval.integer = yyvsp[0].token; ;
    break;}
case 94:
#line 362 "./ldgram.y"
{ yyval.integer = yyvsp[0].token; ;
    break;}
case 95:
#line 364 "./ldgram.y"
{ yyval.integer = yyvsp[0].token; ;
    break;}
case 96:
#line 369 "./ldgram.y"
{
		  yyval.integer =	 exp_get_value_int(yyvsp[0].etree,
					   0,
					   "fill value",
					   lang_first_phase_enum);
		;
    break;}
case 97:
#line 375 "./ldgram.y"
{ yyval.integer = 0; ;
    break;}
case 98:
#line 382 "./ldgram.y"
{ yyval.token = '+'; ;
    break;}
case 99:
#line 384 "./ldgram.y"
{ yyval.token = '-'; ;
    break;}
case 100:
#line 386 "./ldgram.y"
{ yyval.token = '*'; ;
    break;}
case 101:
#line 388 "./ldgram.y"
{ yyval.token = '/'; ;
    break;}
case 102:
#line 390 "./ldgram.y"
{ yyval.token = LSHIFT; ;
    break;}
case 103:
#line 392 "./ldgram.y"
{ yyval.token = RSHIFT; ;
    break;}
case 104:
#line 394 "./ldgram.y"
{ yyval.token = '&'; ;
    break;}
case 105:
#line 396 "./ldgram.y"
{ yyval.token = '|'; ;
    break;}
case 108:
#line 406 "./ldgram.y"
{
		  lang_add_assignment(exp_assop(yyvsp[-1].token,yyvsp[-2].name,yyvsp[0].etree));
		;
    break;}
case 109:
#line 410 "./ldgram.y"
{
		
lang_add_assignment(exp_assop('=',yyvsp[-2].name,exp_binop(yyvsp[-1].token,exp_nameop(NAME,yyvsp[-2].name),yyvsp[0].etree)));
		;
    break;}
case 116:
#line 434 "./ldgram.y"
{ region = lang_memory_region_lookup(yyvsp[0].name); ;
    break;}
case 118:
#line 440 "./ldgram.y"
{ region->current =
		 region->origin =
		 exp_get_vma(yyvsp[0].etree, 0L,"origin", lang_first_phase_enum);
;
    break;}
case 119:
#line 446 "./ldgram.y"
{ region->length = exp_get_vma(yyvsp[0].etree,
					       ~((bfd_vma)0),
					       "length",
					       lang_first_phase_enum);
		;
    break;}
case 120:
#line 455 "./ldgram.y"
{
			lang_set_flags(&region->flags, yyvsp[-1].name);
			;
    break;}
case 122:
#line 464 "./ldgram.y"
{ lang_startup(yyvsp[-1].name); ;
    break;}
case 124:
#line 470 "./ldgram.y"
{ ldemul_hll((char *)NULL); ;
    break;}
case 125:
#line 475 "./ldgram.y"
{ ldemul_hll(yyvsp[0].name); ;
    break;}
case 126:
#line 477 "./ldgram.y"
{ ldemul_hll(yyvsp[0].name); ;
    break;}
case 128:
#line 485 "./ldgram.y"
{ ldemul_syslib(yyvsp[0].name); ;
    break;}
case 130:
#line 491 "./ldgram.y"
{ lang_float(true); ;
    break;}
case 131:
#line 493 "./ldgram.y"
{ lang_float(false); ;
    break;}
case 132:
#line 497 "./ldgram.y"
{ ldlex_expression(); ;
    break;}
case 133:
#line 499 "./ldgram.y"
{ ldlex_popstate(); yyval.etree=yyvsp[0].etree;;
    break;}
case 134:
#line 504 "./ldgram.y"
{ yyval.etree = exp_unop('-', yyvsp[0].etree); ;
    break;}
case 135:
#line 506 "./ldgram.y"
{ yyval.etree = yyvsp[-1].etree; ;
    break;}
case 136:
#line 508 "./ldgram.y"
{ yyval.etree = exp_unop((int) yyvsp[-3].integer,yyvsp[-1].etree); ;
    break;}
case 137:
#line 510 "./ldgram.y"
{ yyval.etree = exp_unop('!', yyvsp[0].etree); ;
    break;}
case 138:
#line 512 "./ldgram.y"
{ yyval.etree = yyvsp[0].etree; ;
    break;}
case 139:
#line 514 "./ldgram.y"
{ yyval.etree = exp_unop('~', yyvsp[0].etree);;
    break;}
case 140:
#line 517 "./ldgram.y"
{ yyval.etree = exp_binop('*', yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 141:
#line 519 "./ldgram.y"
{ yyval.etree = exp_binop('/', yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 142:
#line 521 "./ldgram.y"
{ yyval.etree = exp_binop('%', yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 143:
#line 523 "./ldgram.y"
{ yyval.etree = exp_binop('+', yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 144:
#line 525 "./ldgram.y"
{ yyval.etree = exp_binop('-' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 145:
#line 527 "./ldgram.y"
{ yyval.etree = exp_binop(LSHIFT , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 146:
#line 529 "./ldgram.y"
{ yyval.etree = exp_binop(RSHIFT , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 147:
#line 531 "./ldgram.y"
{ yyval.etree = exp_binop(EQ , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 148:
#line 533 "./ldgram.y"
{ yyval.etree = exp_binop(NE , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 149:
#line 535 "./ldgram.y"
{ yyval.etree = exp_binop(LE , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 150:
#line 537 "./ldgram.y"
{ yyval.etree = exp_binop(GE , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 151:
#line 539 "./ldgram.y"
{ yyval.etree = exp_binop('<' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 152:
#line 541 "./ldgram.y"
{ yyval.etree = exp_binop('>' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 153:
#line 543 "./ldgram.y"
{ yyval.etree = exp_binop('&' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 154:
#line 545 "./ldgram.y"
{ yyval.etree = exp_binop('^' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 155:
#line 547 "./ldgram.y"
{ yyval.etree = exp_binop('|' , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 156:
#line 549 "./ldgram.y"
{ yyval.etree = exp_trinop('?' , yyvsp[-4].etree, yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 157:
#line 551 "./ldgram.y"
{ yyval.etree = exp_binop(ANDAND , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 158:
#line 553 "./ldgram.y"
{ yyval.etree = exp_binop(OROR , yyvsp[-2].etree, yyvsp[0].etree); ;
    break;}
case 159:
#line 555 "./ldgram.y"
{ yyval.etree = exp_nameop(DEFINED, yyvsp[-1].name); ;
    break;}
case 160:
#line 557 "./ldgram.y"
{ yyval.etree = exp_intop(yyvsp[0].integer); ;
    break;}
case 161:
#line 559 "./ldgram.y"
{ yyval.etree = exp_nameop(SIZEOF_HEADERS,0); ;
    break;}
case 162:
#line 562 "./ldgram.y"
{ yyval.etree = exp_nameop(SIZEOF,yyvsp[-1].name); ;
    break;}
case 163:
#line 564 "./ldgram.y"
{ yyval.etree = exp_nameop(ADDR,yyvsp[-1].name); ;
    break;}
case 164:
#line 566 "./ldgram.y"
{ yyval.etree = exp_unop(ABSOLUTE, yyvsp[-1].etree); ;
    break;}
case 165:
#line 568 "./ldgram.y"
{ yyval.etree = exp_unop(ALIGN_K,yyvsp[-1].etree); ;
    break;}
case 166:
#line 570 "./ldgram.y"
{ yyval.etree = exp_nameop(NAME,yyvsp[0].name); ;
    break;}
case 167:
#line 575 "./ldgram.y"
{ yyval.etree = yyvsp[-1].etree; ;
    break;}
case 168:
#line 576 "./ldgram.y"
{ yyval.etree = 0; ;
    break;}
case 169:
#line 579 "./ldgram.y"
{ ldlex_expression(); ;
    break;}
case 170:
#line 581 "./ldgram.y"
{ ldlex_popstate(); ;
    break;}
case 171:
#line 583 "./ldgram.y"
{
			lang_enter_output_section_statement(yyvsp[-5].name,yyvsp[-3].etree,typebits,0,0,0,yyvsp[-2].etree);
			;
    break;}
case 172:
#line 587 "./ldgram.y"
{ldlex_expression();;
    break;}
case 173:
#line 588 "./ldgram.y"
{
		  ldlex_popstate();
		  lang_leave_output_section_statement(yyvsp[0].integer, yyvsp[-1].name);
		;
    break;}
case 175:
#line 597 "./ldgram.y"
{ typebits = SEC_NEVER_LOAD; ;
    break;}
case 176:
#line 598 "./ldgram.y"
{ typebits = 0; ;
    break;}
case 177:
#line 599 "./ldgram.y"
{ typebits = 0; ;
    break;}
case 178:
#line 600 "./ldgram.y"
{ typebits = 0; ;
    break;}
case 179:
#line 601 "./ldgram.y"
{ typebits = 0; ;
    break;}
case 180:
#line 602 "./ldgram.y"
{ typebits = SEC_ALLOC | SEC_LOAD | SEC_HAS_CONTENTS; ;
    break;}
case 181:
#line 607 "./ldgram.y"
{ yyval.etree = yyvsp[-1].etree; typebits =0;;
    break;}
case 182:
#line 608 "./ldgram.y"
{ yyval.etree = yyvsp[-4].etree; ;
    break;}
case 183:
#line 609 "./ldgram.y"
{ yyval.etree= (etree_type *)NULL; typebits = 0; ;
    break;}
case 184:
#line 610 "./ldgram.y"
{ yyval.etree= (etree_type *)NULL;  ;
    break;}
case 185:
#line 615 "./ldgram.y"
{ yyval.name = yyvsp[0].name; ;
    break;}
case 186:
#line 616 "./ldgram.y"
{ yyval.name = "*default*"; ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 465 "/usr/unsupported/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 618 "./ldgram.y"

void
yyerror(arg) 
     const char *arg;
{ 
  if (error_index > 0 && error_index < ERROR_NAME_MAX)
     einfo("%P%F: %S %s in %s\n", arg, error_names[error_index-1]);
  else
     einfo("%P%F: %S %s\n", arg);
}

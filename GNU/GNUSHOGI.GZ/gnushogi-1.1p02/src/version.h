/*
 * This is GNU Shogi.
 * Copyright (c) 1993 Matthias Mutz.
 * GNU Shogi is based on GNU Chess
 * Copyright (c) 1986-1992 Free Software Foundation.
 *
 */
char *version = "1.1";
char *patchlevel = "02";

typedef unsigned int size_t;
struct x { int a; void * operator new (size_t, void *); };
struct x * f(void *p) { return new (p) x; }

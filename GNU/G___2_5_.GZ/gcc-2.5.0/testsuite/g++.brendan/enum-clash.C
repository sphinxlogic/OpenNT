enum color {red, yellow, green=20, blue};
color c = 1;	// this should be an error
int i = yellow;

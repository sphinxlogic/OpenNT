typedef void (*pfv)(double, double);
extern "C" typedef void (*pfv)(double, double);

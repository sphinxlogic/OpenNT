struct bar {
  int : 2 = 1;
};

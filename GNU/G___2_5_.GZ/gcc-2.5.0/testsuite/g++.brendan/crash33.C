extern void foo(void *);
main() {
	foo((struct bar *)0);
}

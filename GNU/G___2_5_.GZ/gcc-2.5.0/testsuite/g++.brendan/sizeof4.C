// ARM $5.3.2

int
main()
{
  // sizeof may not be applied to the type void
  int l = sizeof (void);

  return 0;
}

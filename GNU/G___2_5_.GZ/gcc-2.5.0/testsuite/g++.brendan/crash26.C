struct B {
    B();
};
 
class C : virtual public B
{
  public:
    C() { }
};

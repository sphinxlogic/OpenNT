template <class Q>
class Conc {
public:
	static int body();
};

template <class Q>
int Conc<Q>::body() {return 0;}

main () {
	Conc<int> s2;
}

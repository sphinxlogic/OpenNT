  class Thing{
  private:
	  int x,y;
  public:
	  void doit(int);
  };

  Thing t = {18,19};

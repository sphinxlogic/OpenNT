enum Thing { FIRST, SECOND } ;

main()
{
    Thing x = FIRST ;
    x = 27 ;          // this line should be a type error.
}

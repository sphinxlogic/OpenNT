// The compiler shouldn't give a `invalid operands to binary +' for this
// case.
enum flag { OFF, ON };
enum bool { FALSE = (enum flag) 0, TRUE };

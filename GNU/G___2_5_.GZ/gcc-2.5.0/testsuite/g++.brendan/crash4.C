typedef struct Thing {
		Thing();
	int	x;
} Thing;

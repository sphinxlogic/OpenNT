// used to say invalid lvalue in `&\'
class foo {
        int     a;
    public:
        foo::foo(int a);
};

foo::foo(int a)
{
    foo::a=a;
}

main()
{
foo     obj(4);
}

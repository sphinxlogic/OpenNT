// there should be a warning about foo only defining private methods
class foo {
  int bar();
};

class X { };
void operator[](X& a, X& b) {} // MUST be a member function

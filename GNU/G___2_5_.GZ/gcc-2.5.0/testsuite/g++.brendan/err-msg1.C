class A { };

int i = A::_ter;
int j = A::term;

class A { public: int a; };
void foo7 () { A::a = 3; }

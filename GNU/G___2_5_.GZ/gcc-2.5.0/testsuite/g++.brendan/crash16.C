class Graph {
public:
      unsigned         char N;
                       Graph(void) {};
}

Graph::Graph(void)
{    N = 10;
}


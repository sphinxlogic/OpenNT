struct CharList { int i; };

const CharList& terminals = { 1 };

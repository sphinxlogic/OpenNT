// The compiler should not error about taking the addr of main in this example.
    class fred {
      private:
        void main () {
        }
      public:
        fred ( ) {
            void (*xxx)() = (void (*)())&fred::main;
        }
    };


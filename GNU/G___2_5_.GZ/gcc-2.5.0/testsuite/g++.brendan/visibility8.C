// Make sure private inheritance doesn't affect the visibility of
// static members.
class foo
{
public:
  static int y;
};
class foo1 : private foo
{ };
class foo2 : public foo1
{ public:
  void bar () { y; }
};

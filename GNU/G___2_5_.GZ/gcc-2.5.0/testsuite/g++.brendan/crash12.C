class X
{
        int i;
public:
        X(int j);
}

X *x = new X[10]();

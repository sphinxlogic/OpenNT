void f( int a) {
  int a;	// this should be an error now
	{
		int a;
	}
};

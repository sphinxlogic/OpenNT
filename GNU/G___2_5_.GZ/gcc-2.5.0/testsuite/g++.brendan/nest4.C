class vec {
    class blah { };

    ::vec::blah	satan( 0);
    blah	herman( 0);
};

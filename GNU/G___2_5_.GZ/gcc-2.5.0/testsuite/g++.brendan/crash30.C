#include <String.h>

main(void) {

  String a[] = {"Hello"};

}

enum color { red, green, blue, orange, brown };

struct s {
        enum color      field:2;
};

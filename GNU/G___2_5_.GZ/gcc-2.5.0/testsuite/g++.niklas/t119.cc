unsigned long foo(unsigned long x)
{
  return x & ~0104000;
}

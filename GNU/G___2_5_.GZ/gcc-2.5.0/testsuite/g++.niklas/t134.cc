extern "C" int f ();
struct A { static void f () {} };

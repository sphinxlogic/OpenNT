struct S { S (); ~S (); };
void f () { while (1) S s; }


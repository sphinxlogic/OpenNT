struct A;
void f (A*);
A* A;
void g () { f (A); }

extern "C" void f (char*);
void f (const char*) {}

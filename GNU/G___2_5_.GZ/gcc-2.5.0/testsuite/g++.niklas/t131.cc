struct A { static A a; };
A f () { return A::a; }

struct A { A(); virtual void f(); };
struct B : virtual A { B(); };
B b1;
B b2 = b1.B();



struct S { S(); };
void f() { S s; s.S(); }

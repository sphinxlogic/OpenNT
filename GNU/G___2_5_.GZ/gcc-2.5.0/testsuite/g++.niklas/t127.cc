struct A { struct B { ~B (); }; };
A::B::~B () {}

struct S { S(); };
void f(S) {}

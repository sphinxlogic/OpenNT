template <class T> class C1 {};
class C1<int> C1_int_object;

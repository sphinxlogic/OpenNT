class X { X (int); };
void X (int);
void f () { X (1); }

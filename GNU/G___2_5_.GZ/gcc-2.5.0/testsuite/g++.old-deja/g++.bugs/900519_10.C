// g++ 1.37.1 bug 900519_10

// g++ allows the declaration of const members within classes/structs/unions
// which have no explicit constructor declared.

// Cfront 2.0 does not allow this.

// See also g++ 1.36.1 bug 900205_01

// keywords: const members, constructors, member initialization

struct struct_0 {
  const int const_member;	// ERROR - no explicit constructor
};

int main () { return 0; }

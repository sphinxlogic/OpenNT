// g++ 1.37.1 bug 900405_01

// The C++ Reference Manual says (in section 5.4) "Types may not be defined
// in casts."

// g++ fails to flag errors for cases where an attempt is made to define
// a struct, class, union, or enum type within a cast.

// keywords: casts, type definitions, tagged types

void f ()
{
  (enum e { red, green } *) 0;		// ERROR - missed, XFAIL *-*-*
  (struct s { int member; } *) 0;	// ERROR - missed, XFAIL *-*-*
  (union u { int member; } * ) 0;	// ERROR - missed, XFAIL *-*-*
  (class c { int member; } *) 0;	// ERROR - missed, XFAIL *-*-*
}

int main () { return 0; }

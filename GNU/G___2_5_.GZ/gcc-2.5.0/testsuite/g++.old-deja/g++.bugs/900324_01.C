// g++ 1.37.1 bug 900324_01

// g++ fails to flag errors for uses of anachronistic features such as
// overload statements.

// Errors should probably be issued for such usage unless the -traditional
// option is used.

// Cfront 2.0 flags such usage as an error when the +p (pure-language) option
// is used.

// Cfront 2.0 passes this test.

// keywords: anachronism, overload, keyword

overload function;		// ERROR - anachronism "overload" used

void function (int i)
{
}

void function (double d)
{
}

int main () { return 0; }

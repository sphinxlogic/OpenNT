// g++ 1.36.1 bug 900105_01

// g++ gives erroneous errors regarding the number of parameters to static
// operators.

// Cfront 2.0 passes this test.

// keywords: operators, static members, formal parameters

class class0 {

  int data_member;

public:

  static int operator == (class0&);	// gets bogus error, XFAIL *-*-*
  static int operator ! ();		// gets bogus error, XFAIL *-*-*
};

int class0::operator== (class0&) { return 0; }
int class0::operator! () { return 0; }

int main () { return 0; }

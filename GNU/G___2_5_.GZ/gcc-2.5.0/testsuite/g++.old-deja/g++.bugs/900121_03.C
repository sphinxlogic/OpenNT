// g++ 1.36.1 bug 900121_03

// It is illegal for a pair of functions to overload one another where the
// only difference between the two functions is that one accepts a given
// type of value while the other one accepts a reference to the same type
// of value.

// g++ does not detect such errors.

// Cfront 2.0 disgnoses an error on the second definition of test_function_0
// and on the call to that (overloaded) function.

// Cfront 2.0 passes this test.

// keywords: function overloading, references, formal parameters

class test {
};

void test_function_0 (test & arg) {	// ERROR - conflict with below
}

void test_function_0 (test arg) {	// ERROR - illegal overloading
}

test f;

void global_function ()
{
  test_function_0 (f);
}

int main () { return 0; }

// g++ 1.37.1 bug 900519_11

// g++ allows a class for which an implicit default X::X() constructor must
// be created (implicitly by the compiler) to be derived from another class
// which for which the default X::X() constructor is explicitly private.
// This is illegal.

// Cfront 2.0 passes this test.

// See also g++ 1.36.1 bug 900205_04

// keywords: default constructor, inheritance, private

struct struct0 {
  int data_member;

  struct0 (int, void *);
private:
  struct0 ();
};

struct0::struct0 (int, void *)
{
}

struct0::struct0 ()
{
}

struct struct0_derived_struct_0 : public struct0 { };	// ERROR - , XFAIL *-*-*

// struct0_derived_struct_0 object;	// would give g++ error if compiled

int main () { return 0; }

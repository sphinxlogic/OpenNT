// g++ 1.36.1 bug 891229_02

// g++ limits the scope of names which are declared as typedef names within
// another type to that other type.

// This conflicts with the (global) scope given to such names by cfront 2.0.

// Cfront 2.0 passes this test.

// keywords: typedef, nested types, scope

struct foo {
	foo ();
	typedef void (*function_p) (void);
};

function_p fp;		// gets bogus errors, XFAIL *-*-*

foo::foo () {}

int main () { return 0; }

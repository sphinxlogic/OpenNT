// Build don't link:
// A pointer to member function test case.

struct X
{
};

int * (X::* fee ())()
{
}

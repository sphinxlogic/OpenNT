// Build don't link:

class path {
public:
        path (const path& r)
            { "\"";
	      '\'';
            }
};

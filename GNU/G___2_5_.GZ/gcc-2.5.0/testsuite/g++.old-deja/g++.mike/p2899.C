template <class A>
  int test()
{ // ERROR - eof should be found

// Build don't link:

int shake_zero()
{
}

int shake_one()
{
}

int (*foo)();

int main(int a)
{
  foo = a ? shake_zero : shake_one;
  return 0;
}

// Build don't link:
// Special g++ Options:

// This should compile.

int foo (signed char *);
int foo (char *);

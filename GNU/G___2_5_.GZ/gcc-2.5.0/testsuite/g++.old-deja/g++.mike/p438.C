// Build don't link:

class D;

class C
{
   public:
   void test() const;
};

class D
{
   public:
   void a(C& b);
};

void C::test() const
{
   D d;

   d.a(*this);	// XERROR - *this is const, so should get error
}

    char HexDigit(unsigned char ch) { return ch < 'f'; }

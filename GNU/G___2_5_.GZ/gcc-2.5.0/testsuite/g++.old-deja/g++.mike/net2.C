// Build don't link:
// Here is another program from the net.

class B;

class A {
  private:
    A(B *);
  public:
    A(long);
};

A a(0); // XERROR - should be ambigious

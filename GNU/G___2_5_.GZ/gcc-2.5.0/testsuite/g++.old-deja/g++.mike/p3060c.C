// A new problem with my pointer to member function work.
// Build don't link:

class Foo
{
 public:
  int x;
  int y;
  Foo (int i, int j) { x = i; y = j; }
  operator int ();
};

int Foo::operator int() { return x; }

Foo foo(10, 11);

int
main()
{
  int Foo::* pmi = &Foo::y;
  return foo.*pmi;
}

// Build don't link:

extern "C" 
{
  int printf(const char *, ...);
};


void Munge(int& x) 
{
   x = 2;
}


class A 
{
 public:
   int i;
   A(int x) : i(x) {}
   void Safe() const;
};

void
A::Safe() const 
{
   Munge(i);	// ERROR - should not be able to modify a const object
}

main()
{
   const A a(1);
   a.Safe();
}

// Build don't link: 

template <class A, class B>
int f (const A& a, const B& b = 37) {
  return sizeof (A) + sizeof (B);
}

int foo () { return f (99); }	// XBOGUS - 

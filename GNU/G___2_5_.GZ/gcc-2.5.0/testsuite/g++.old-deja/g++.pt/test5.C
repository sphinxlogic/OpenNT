// Build don't link: 

template <char *a, const char *b, char *const c> class A{int x;};

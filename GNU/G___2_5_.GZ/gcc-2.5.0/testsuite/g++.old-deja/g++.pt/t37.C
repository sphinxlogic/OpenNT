// Build don't link: 

class A {
public:
  A(int);
  A(float);
  ~A();
};

A::A() {		// ERROR - 
}
  
A::A(int) {
}
  
A::~A() {
}
  

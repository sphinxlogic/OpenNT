// Build don't link: 

#include "t33z.h"		// ERROR - no header!

A<double> ad;			// ERROR - no A

int quux () { return ad.foo (); }	// ERROR - no ad

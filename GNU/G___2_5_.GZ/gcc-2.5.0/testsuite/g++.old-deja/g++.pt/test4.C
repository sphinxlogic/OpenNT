// Build don't link: 

template <class x, int b> class X : public B { int y[b]; };

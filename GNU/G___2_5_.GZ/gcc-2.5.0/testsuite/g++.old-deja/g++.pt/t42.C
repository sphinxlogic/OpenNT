// Build don't link: 

extern "C" abort ();

struct A {
  struct stat {
    int x;
    stat (int j) { abort (); }
  };
  static int stat (double d) { return 0; }	// XBOGUS - cfront takes it
  static int zap () {
    stat (0);
    return stat (1);	// XBOGUS - should this work?
  }	// XBOGUS - should happen
};

int main () {
  return A::zap ();
}

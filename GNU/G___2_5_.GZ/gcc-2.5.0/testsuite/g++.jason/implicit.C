#include <string.h>
#include <iostream.h>

main ()
{
  char bar[5];
  strncpy (bar, "foo", 5);
  cout << "*PASS*";
}

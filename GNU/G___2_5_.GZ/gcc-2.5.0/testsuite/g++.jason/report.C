template <char C>
class badoo
{
};

template <int (*F) (int)>
class doowop
{
};

struct A
{
  int a;
  ~A () { a = 0; }
  operator int () { return a; }
};

extern "C" int atoi (char *);

int (*fee)(char *) = atoi;
int (**bar)(char *) = &fee;

char *s = "4";
char **sp = &s;
char ***spp = &sp;

int foo (int a = (**bar) (s))
{
  return doowop<foo>::bar;
}

int foo2 (int (*a)(int) = &foo)
{
  undef4 (1);
  return 1;
}

class X{
  class Y{};
};

typedef int const * bar ();
typedef bar const * const * bar2;

bar2 baz (X::Y y)
{
  X::Y f;
  bar2 wa [5];
  wa[0] = baz(f);
  undef2 (1);
}

int ninny ()
{
  struct A
    {
      static int ninny2 () { return badoo<'\001'>::foo; }
    };

  return A::ninny2();
}

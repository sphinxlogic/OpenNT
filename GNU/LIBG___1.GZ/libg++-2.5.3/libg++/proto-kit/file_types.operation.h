#define FILE_TYPES_OPERATION(OPERATION)  \
OPERATION(Substrate) \
OPERATION(SubstrateUnix) \
OPERATION(SubstrateImmediate) \
OPERATION(SubstrateSimple) \
OPERATION(SubstrateUnixDirectory) \
OPERATION(SubstrateUnixImmediate) \
OPERATION(SubstrateUnixSimple) \
OPERATION(SubstrateSimpleWhole) \
OPERATION(SubstrateSimplePartial) \
OPERATION(SubstrateUnixDirectoryImmediate) \
OPERATION(SubstrateUnixDirectorySimple) \
OPERATION(SubstrateUnixSimpleWhole) \
OPERATION(SubstrateUnixSimplePartial) \
OPERATION(SubstrateUnixDirectorySimpleWhole) \
OPERATION(SubstrateUnixDirectorySimplePartial) \


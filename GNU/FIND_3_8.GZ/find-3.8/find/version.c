char *version_string = "GNU find version 3.8\n";

../bash ./redir-test-2.sh < /etc/passwd

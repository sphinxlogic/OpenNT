/*
 * This is XShogi.
 * Copyright (c) 1993 Matthias Mutz.
 * XShogi is based on XBoard 2.0
 * Copyright (c) 1992 Free Software Foundation.
 *
 */
char *version = "1.2";
char *patchlevel = "02";

char version[] = "ECC version 1.2.1";

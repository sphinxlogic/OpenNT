/* If you wish to use at_pr (tell the person responsible when a
   PR hasn't been analyzed within its notification period), define
   this macro.  */
#define NOTIFY		TRUE

/* If GNATS should send a reply to the person who submitted the bug, telling
   them the PR number and other information, define this to TRUE.  */
#define ACKNOWLEDGE	TRUE

/* Define this to be the submitter-id to be used when a PR comes in either
   without one, or with a bogus id.  An alternative to "unknown" might be
   "net", if you anticipate getting lots of reports from the Net.  */
#define DEFAULT_SUBMITTER	"unknown"

/* Every email message has one or more `Received:' headers to tell you
   how a message got from the sender to the recipient.  Define this to
   be TRUE if you want GNATS to preserve all of those `Received:' headers.
   If you tend not to use the information, define it to be FALSE so GNATS
   will only keep the first `Received:' header.  */
#define KEEP_RECEIVED_HEADERS	TRUE

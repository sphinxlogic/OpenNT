#!/bin/csh
true || exit 0
export PATH || exit 0
exit 1

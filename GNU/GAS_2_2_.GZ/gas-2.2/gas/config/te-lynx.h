#define TE_LYNX

#include "obj-format.h"

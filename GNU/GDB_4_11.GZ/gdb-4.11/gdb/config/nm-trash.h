/* this file is temporary scaffolding until all hosts have the
   native/target/host split in place.  FIXME.  */

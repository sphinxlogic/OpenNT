#ifdef __GNUG__
#pragma implementation
#endif
#include <compare.h>

usemymalloc=n
mallocsrc=''
mallocobj=''

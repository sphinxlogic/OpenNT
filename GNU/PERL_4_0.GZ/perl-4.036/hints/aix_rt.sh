ccflags="$ccflags -a -DCRIPPLED_CC"

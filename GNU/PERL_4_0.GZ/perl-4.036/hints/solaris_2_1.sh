d_vfork='undef'
d_wait4='undef'
i_dirent='undef'
i_sys_dir='define'

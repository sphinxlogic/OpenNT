optimize="-O0"
ccflags="$ccflags -nw"

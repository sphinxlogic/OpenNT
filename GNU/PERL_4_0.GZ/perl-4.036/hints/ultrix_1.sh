ccflags="$ccflags -DULTRIX_STDIO_BOTCH"

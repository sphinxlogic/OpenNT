optimize='-opt 2'
cflags='-A nansi cpu,mathchip -O -U__STDC__'
echo "Some tests may fail unless you use 'chacl -B'.  Also, op/stat"
echo "test 2 may fail because Apollo doesn't support mtime or ctime."

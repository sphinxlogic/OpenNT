optimize='+O1'
ccflags="$ccflags -Wc,-Nw500"

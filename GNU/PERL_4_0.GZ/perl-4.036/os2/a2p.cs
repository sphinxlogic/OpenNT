(-W1 -Od -Ocgelt a2p.y{a2py.c})
(-W1 -Od -Ocgelt hash.c str.c util.c walk.c)

setargv.obj
..\os2\perl.def
a2p.exe

-AL -LB -S0x9000

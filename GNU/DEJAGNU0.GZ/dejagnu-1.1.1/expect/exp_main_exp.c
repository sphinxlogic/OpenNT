/* main.c - main() and some logging routines for expect

Written by: Don Libes, NIST, 2/6/90

Design and implementation of this program was paid for by U.S. tax
dollars.  Therefore it is public domain.  However, the author and NIST
would appreciate credit if this program or parts of it are used.
*/

#include "exp_conf.h"
#include <stdio.h>
#include "tcl.h"
#include "exp_global.h"
#include "exp_rename.h"
#include "exp_command.h"
#include "exp_log.h"
#include "exp_main.h"

void
main(argc, argv)
int argc;
char *argv[];
{
	Tcl_Interp *interp = Tcl_CreateInterp();

	exp_init(interp);
	exp_parse_argv(interp,argc,argv);

	/* become interactive if requested or "nothing to do" */
	if (exp_interactive) (void) exp_interpreter(interp);
	else if (exp_cmdfile) exp_interpret_cmdfile(interp,exp_cmdfile);
	else if (exp_cmdfilename) exp_interpret_cmdfilename(interp,exp_cmdfilename);

	/* assert(exp_cmdlinecmds != 0) */

	exp_exit(interp,0);
}


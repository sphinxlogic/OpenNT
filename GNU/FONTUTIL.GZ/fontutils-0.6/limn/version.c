char *version_string = "limn version 0.6";

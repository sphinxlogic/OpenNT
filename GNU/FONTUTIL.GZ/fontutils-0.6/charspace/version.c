char *version_string = "charspace version 0.6";

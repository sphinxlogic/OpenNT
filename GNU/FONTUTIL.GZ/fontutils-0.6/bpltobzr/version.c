char *version_string = "bpltobzr version 0.6";

char *version_string = "imageto version 0.6";

void do_indirect PARAMS ((ldsym_type *));
void add_indirect PARAMS ((asymbol **));

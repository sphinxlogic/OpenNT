void init_bfd_error_vector PARAMS ((void));

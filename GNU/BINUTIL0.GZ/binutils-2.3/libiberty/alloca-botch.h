/* RS/6000 AIX botched alloca and requires a pragma, which ordinary compilers
   throw up about, so we have to put it in a specially-configured file.
   Like this one.  */

#pragma alloca

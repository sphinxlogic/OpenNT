int nothing ()

{
    int x = 3 ;
    return x ;
}


main ()

{
    int y ;
    
    y = nothing () ;
    printf ("hello\n") ;
}

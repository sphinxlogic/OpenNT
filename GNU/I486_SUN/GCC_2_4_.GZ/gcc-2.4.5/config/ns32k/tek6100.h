#include "ns32k/tek6000.h"

#undef CPP_PREDEFINES
#define CPP_PREDEFINES \
 "-Dns32000 -Dns32k -Dns16000 -Dns32016 -DUTek -DUTEK -Dbsd -DBSD -Dstratos"


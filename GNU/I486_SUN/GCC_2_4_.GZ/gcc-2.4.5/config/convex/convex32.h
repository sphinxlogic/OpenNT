/* tm.h file for a Convex C32xx.  */

#define TARGET_DEFAULT 004

#include "convex/convex.h"

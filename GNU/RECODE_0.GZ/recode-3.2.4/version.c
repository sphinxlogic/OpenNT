/* Conversion of files between different charsets and usages.
   Copyright (C) 1990 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1989.
*/

#ifndef __STDC__
#define const
#define volatile
#endif

#include <stdio.h>

/* Should stay one a single line, for `make dist' to work.  */
const char *version_string = "\nrecode version 3.2.4\n";

const char *copyright_line
  = "Copyright (C) 1991, 1992 Free Software Foundation, Inc.\n";

/*-----------------------------------------------------------.
| Prints package name and version, and the short Copyright.  |
`-----------------------------------------------------------*/

void
print_version (void)
{
  fprintf (stderr, "%s%s", version_string, copyright_line);
}

/*-----------------------------------.
| Prints a more detailed Copyright.  |
`-----------------------------------*/

void
print_copyright (void)
{
  fprintf (stderr, "\n\
This program is free software; you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License as published by\n\
the Free Software Foundation; either version 2, or (at your option)\n\
any later version.\n\
\n\
This program is distributed in the hope that it will be useful,\n\
but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
GNU General Public License for more details.\n\
\n\
You should have received a copy of the GNU General Public License\n\
along with this program; if not, write to the Free Software\n\
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n\
\n\
Mail all suggestions and bug reports for this program to its author,\n\
Francois Pinard <pinard@iro.umontreal.ca>.\n\
\n");
}

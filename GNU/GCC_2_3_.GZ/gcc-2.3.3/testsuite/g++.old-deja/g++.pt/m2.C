// Build don't link: 

struct A { A() { a = 2; } int a; };

int f1 () {
  struct A { A() { a = 2; } int a; };
  A aa;
  return aa.a;
}
char xx[]="/*
../tests/m2.cc: In function int f1 ():
../tests/m2.cc:4: redefinition of `struct A'
../tests/m2.cc:4: warning: empty declaration
../tests/m2.cc:5: aggregate `aa' has incomplete type and cannot be initialized
../tests/m2.cc:5: storage size of `aa' isn't known
../tests/m2.cc:6: `aa' undeclared (first use this function)
../tests/m2.cc:6: (Each undeclared identifier is reported only once
../tests/m2.cc:6: for each function it appears in.)
../tests/m2.cc:7: warning: control reaches end of non-void function
 */
";

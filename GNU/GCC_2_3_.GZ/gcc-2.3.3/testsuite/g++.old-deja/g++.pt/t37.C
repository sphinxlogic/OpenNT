// Build don't link: 

class A {
public:
  A(int);
  A(float);
  ~A();
};

A::A() {
}
  
A::A(int) {
}
  
A::~A() {
}
  

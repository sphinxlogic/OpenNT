// Build don't run:

/*


*/


template <class X> class TC {
public:
  X aaa;
  static X sss;
  TC::TC(X a) {aaa = a; }
  TC::TC(X a, X s) {aaa = a; sss = s; }
  void sz(X s) { sss = s; }
};


TC<long> xjj(1,2);

int main(int,char*) {
  TC<float> xff(9.9,3.14);
  xjj.sz(123);
  xff.sz(2.71828);
}

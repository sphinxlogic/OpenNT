// Build don't link: 

#include "t33z.h"

A<double> ad;

int quux () { return ad.foo (); }

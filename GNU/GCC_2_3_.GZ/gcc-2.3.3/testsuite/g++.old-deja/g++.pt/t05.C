// Build don't link: 

template <class A> class B {
  A a;
 public:
  B(A&aa);
  ~B();
};
static B<int> b_int (3);


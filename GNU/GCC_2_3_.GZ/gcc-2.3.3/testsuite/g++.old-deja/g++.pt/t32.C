// Build don't link: 

# 1 "test file 32.cc"
#pragma implementation "test file 32.cc"
template <class X> struct A {
  int fooo (int x);
  int x;
  inline int y () { return 3; }
  inline int z () { return 5; }
};

template <class Y> int A<Y>::fooo (int t) { return (x?y:z)() + t; };

A<int> ai;

int frop () { return ai.fooo (100); }

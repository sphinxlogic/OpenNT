// Build don't link: 

struct A {
  friend struct B : A {
    int x;
  };
  int y;
};

// g++ 1.36.1 bug 900205_01

// g++ allows the declaration of reference members within
// clases which have no explicit constructor declared.

// Cfront 2.0 does not allow this.

// keywords: reference members, constructors, member initialization

class c0 {

  int &int_ref;

};			// ERROR - no explicit constructor for int_ref

int main () { return 0; }

// g++ 1.37.1 bug 900515_02

// g++ generates errors for the following legal code because it fails to
// recongize that an object of one class (i.e. "struct_2") may be implicitly
// converted to an object of one of its own public base classes (i.e.
// "struct_1").

// keywords: user-defined type conversion operator, derived types

struct struct_3;

struct struct_1 {
};

struct struct_2 : public struct_1 {
  struct_2 ();
  struct_2 (struct_3&);
};

struct_2::struct_2 ()
{
}

struct_2::struct_2 (struct_3&)
{
}

struct struct_3 {
};

struct_2 struct_2_obj;

struct_1 struct_1_obj;

struct_3 struct_3_obj;

void test ()
{
  struct_2_obj = struct_3_obj;		// OK
  struct_1_obj = struct_3_obj;		// gets bogus error
}

int main () { return 0; }

// g++ 1.36.1 bug 900114_01

// g++ fails to flag errors for all cases where the inner statement
// in a conditional or looping statement is a simple declarative statement.

// Cfront 2.0 catches all these errors.

// keywords: declarative statement, conditional statement, looping statement

int i;

void func ()
{

  if (i)
    int then_part;	// ERROR - caught
  else
    int then_part;	// ERROR - caught

  while (i)
    int while_body;	// ERROR - missed

  do
    int do_body;	// ERROR - missed
  while (i);

  for (;;)
    int for_body;	// ERROR - missed
}

int main () { return 0; }

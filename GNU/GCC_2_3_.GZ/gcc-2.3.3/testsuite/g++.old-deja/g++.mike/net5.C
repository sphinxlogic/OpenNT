// Build don't link:
// Special g++ Options:

volatile void aborty();
volatile void oink() {
  abort() ;
}

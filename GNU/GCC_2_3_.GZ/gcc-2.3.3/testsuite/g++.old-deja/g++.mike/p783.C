extern "C" void printf (char *, ...);

class C {
public:
  C() { }
  ~C() { }
};

main(int argc, char**argv) {
  C c,d;
  c = (argc&1) ? C() : d;
  return 0;
}

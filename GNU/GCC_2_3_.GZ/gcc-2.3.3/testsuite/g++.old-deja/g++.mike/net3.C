// Build don't link:
// Here is another program from the net.

class bool {
 public:
  int val;
  
  bool(int i =0);
  operator int();
};

bool& foo()
{
  static bool status;
  return status;
}

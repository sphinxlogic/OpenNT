// This represents ideas from p0000755
// It checks to see if you can define your own global delete operator.

extern "C" void exit(int);

void operator delete(void *p) {
  exit(0);
}

main () {
  int* i = new int;
  delete i;
  return 1;
}

// Build don't link:

class Base {
public:
	int foo;
};

class Derived : public Base {
public:
	int bar;
};

void func(Base&);

void func2(const Derived& d) {
	func(d);		// ERROR - should be error because of const
}

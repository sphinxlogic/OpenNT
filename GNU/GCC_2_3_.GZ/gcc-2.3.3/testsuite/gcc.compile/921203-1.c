char dispstr[];
f()
{
  strcpy(dispstr,"xxxxxxxxxxx");
}

long long x=0;y(){x=0;}

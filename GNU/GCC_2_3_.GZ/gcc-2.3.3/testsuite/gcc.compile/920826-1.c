f(int*x){goto*(char)*x;}

int f(int c){return f(c--);}
g(){}

struct
{
int n:1,c:1;
}p;

f()
{
p.c=p.n=0;
}

x(){if(&&e-&&b<0)x();b:goto*&&b;e:;}

char a[]={4,5};f(n){return a[n<2?n:0];}

short x(a)unsigned a;{a=32987799;return a;}

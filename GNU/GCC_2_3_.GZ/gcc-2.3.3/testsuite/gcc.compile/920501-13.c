typedef struct{int i;}t;inline y(t u){}x(){t u;y(u);}

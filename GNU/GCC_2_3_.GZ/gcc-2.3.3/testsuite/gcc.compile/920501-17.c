x(){static const char x[]="x";char y[2];y[0]=x[1];}

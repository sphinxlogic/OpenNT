f(){static g();return g();}

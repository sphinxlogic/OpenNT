f(double*a,int m){int j;for(j=0;j<m;j++)a[j]=1;}
g(double*a){int j;for(j=0;j<4;j++)a[j]=1;}


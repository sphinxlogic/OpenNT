x(){int y[]={};}

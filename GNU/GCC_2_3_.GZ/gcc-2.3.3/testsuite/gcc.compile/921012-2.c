struct foo {
int a,b,c;
};
f(struct foo*a,struct foo*b)
{
*a=*b;
}

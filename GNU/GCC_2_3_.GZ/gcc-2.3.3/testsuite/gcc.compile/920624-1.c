int B[],Q[];
f(){int s;for(s=0;s<=1;s++)switch(s){case 2:case 3:++B[s];case 4:case 5:++Q[s];}}

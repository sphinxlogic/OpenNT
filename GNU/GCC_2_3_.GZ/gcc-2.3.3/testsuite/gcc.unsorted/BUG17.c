double d;

main()
{
  int i;

  i = (int) d;
}

foo ()
{
  return (int)&foo;
}

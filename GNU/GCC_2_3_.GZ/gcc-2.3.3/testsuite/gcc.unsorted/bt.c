main ()
{
  int i;

  for (i = 1000000; --i;)
    ;
}

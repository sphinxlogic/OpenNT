foo (short *p, short a)
{
  return a < *p;
}

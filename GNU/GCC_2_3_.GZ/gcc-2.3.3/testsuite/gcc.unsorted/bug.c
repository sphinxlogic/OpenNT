foo (a, b)
{
  return a - 65536;
}

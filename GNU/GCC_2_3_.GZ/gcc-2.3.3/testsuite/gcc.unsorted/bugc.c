
int
reg0indreg1 (r0, p1)
     short  r0;  short *p1;
{
  return (r0);
}

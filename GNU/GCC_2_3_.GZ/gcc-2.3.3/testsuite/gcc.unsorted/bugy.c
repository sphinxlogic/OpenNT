extern	struct	_iobuf {
	int	_cnt;
	char	*_ptr;
	char	*_base;
	int	_bufsiz;
	short	_flag;
	char	_file;
} _iob[20 ];

struct _iobuf 	*fopen();
struct _iobuf 	*fdopen();
struct _iobuf 	*freopen();
long	ftell();
char	*gets();
char	*fgets();
char	*sprintf();

typedef int jmp_buf[11];

extern int target_flags;

enum reg_class
{ NO_REGS, BYTE_POINTER_REG, FUNNEL_COUNT_REG, QUOTIENT_REG,
  COUNT_REMAINING_REG, SPECIAL_REGS, GENERAL_REGS, ALL_REGS,
  LIM_REG_CLASSES };

extern int may_call_alloca;
extern int current_function_pretend_args_size;

enum rtx_code  {

  UNKNOWN ,

  NIL ,

  EXPR_LIST ,

  INSN_LIST ,

  MATCH_OPERAND ,

  MATCH_DUP ,

  MATCH_OPERATOR ,

  DEFINE_INSN ,

  DEFINE_PEEPHOLE ,

  DEFINE_COMBINE ,

  DEFINE_EXPAND ,

  SEQUENCE ,

  ADDRESS ,

  INSN ,

  JUMP_INSN ,

  CALL_INSN ,

  BARRIER ,

  CODE_LABEL ,

  NOTE ,

  INLINE_HEADER ,

  PARALLEL ,

  ASM_INPUT ,

  ASM_OPERANDS ,

  ADDR_VEC ,

  ADDR_DIFF_VEC ,

  SET ,

  USE ,

  CLOBBER ,

  CALL ,

  RETURN ,

  CONST_INT ,

  CONST_DOUBLE ,

  CONST ,

  PC ,

  REG ,

  SUBREG ,

  STRICT_LOW_PART ,

  MEM ,

  LABEL_REF ,

  SYMBOL_REF ,

  CC0 ,

  QUEUED ,

  IF_THEN_ELSE ,

  COMPARE ,

  PLUS ,

  MINUS ,

  NEG ,

  MULT ,

  DIV ,

  MOD ,

  UMULT ,
  UDIV ,
  UMOD ,

  AND ,

  IOR ,

  XOR ,

  NOT ,

  LSHIFT ,
  ASHIFT ,
  ROTATE ,

  ASHIFTRT ,
  LSHIFTRT ,
  ROTATERT ,

  PRE_DEC ,
  PRE_INC ,
  POST_DEC ,
  POST_INC ,

  NE ,
  EQ ,
  GE ,
  GT ,
  LE ,
  LT ,
  GEU ,
  GTU ,
  LEU ,
  LTU ,

  SIGN_EXTEND ,

  ZERO_EXTEND ,

  TRUNCATE ,

  FLOAT_EXTEND ,
  FLOAT_TRUNCATE ,

  FLOAT ,

  FIX ,

  UNSIGNED_FLOAT ,

  UNSIGNED_FIX ,

  ABS ,

  SQRT ,

  FFS ,

  SIGN_EXTRACT ,

  ZERO_EXTRACT ,

  LAST_AND_UNUSED_RTX_CODE};	

				

extern int rtx_length[];

extern char *rtx_name[];

extern char *rtx_format[];

enum machine_mode {

 VOIDmode,

 QImode, 		
 HImode,

 PSImode,
 SImode,
 PDImode,
 DImode,
 TImode,
 QFmode,
 HFmode, 	
 SFmode,
 DFmode,
 XFmode,
 TFmode,
 CQImode,
 CHImode,
 CSImode,
 CDImode,
 CTImode,
 CQFmode,
 CHFmode,
 CSFmode,
 CDFmode,
 CXFmode,
 CTFmode,

 BImode, 	

 BLKmode,

 EPmode,

MAX_MACHINE_MODE };

extern char *mode_name[];

enum mode_class { MODE_RANDOM, MODE_INT, MODE_FLOAT,
		  MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MODE_FUNCTION };

extern enum mode_class mode_class[];

extern int mode_size[];

extern int mode_unit_size[];

extern enum machine_mode mode_wider_mode[];

typedef union rtunion_def
{
  int rtint;
  char *rtstr;
  struct rtx_def *rtx;
  struct rtvec_def *rtvec;
  enum machine_mode rttype;
} rtunion;

typedef struct rtx_def
{

  enum rtx_code code : 16;

  enum machine_mode mode : 8;

  unsigned int jump : 1;

  unsigned int call : 1;

  unsigned int unchanging : 1;

  unsigned int volatil : 1;

  unsigned int in_struct : 1;

  unsigned int used : 1;

  unsigned integrated : 1;

  rtunion fld[1];
} *rtx;

typedef struct rtvec_def{
  unsigned num_elem;		
  rtunion elem[1];
} *rtvec;

enum reg_note { REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
		REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
		REG_NONNEG = 8, REG_UNSET = 9 };

extern char *reg_note_name[];

extern char *note_insn_name[];

extern rtx rtx_alloc ();
extern rtvec rtvec_alloc ();
extern rtx find_reg_note ();
extern rtx gen_rtx ();
extern rtx copy_rtx ();
extern rtvec gen_rtvec ();
extern rtvec gen_rtvec_v ();
extern rtx gen_reg_rtx ();
extern rtx gen_label_rtx ();
extern rtx gen_inline_header_rtx ();
extern rtx gen_lowpart ();
extern rtx gen_highpart ();
extern int subreg_lowpart_p ();
extern rtx make_safe_from ();
extern rtx memory_address ();
extern rtx get_insns ();
extern rtx get_last_insn ();
extern rtx start_sequence ();
extern rtx gen_sequence ();
extern rtx expand_expr ();
extern rtx output_constant_def ();
extern rtx immed_real_const ();
extern rtx immed_real_const_1 ();
extern rtx immed_double_const ();
extern rtx force_const_double_mem ();
extern rtx force_const_mem ();
extern rtx get_parm_real_loc ();
extern rtx assign_stack_local ();
extern rtx protect_from_queue ();
extern void emit_queue ();
extern rtx emit_move_insn ();
extern rtx emit_insn ();
extern rtx emit_jump_insn ();
extern rtx emit_call_insn ();
extern rtx emit_call_insn_before ();
extern rtx emit_insn_before ();
extern rtx emit_insn_after ();
extern rtx emit_label ();
extern rtx emit_barrier ();
extern rtx emit_barrier_after ();
extern rtx emit_note ();
extern rtx emit_line_note ();
extern rtx emit_line_note_force ();
extern rtx prev_real_insn ();
extern rtx next_real_insn ();
extern rtx next_nondeleted_insn ();
extern rtx plus_constant ();
extern rtx find_equiv_reg ();
extern rtx delete_insn ();
extern rtx adj_offsettable_operand ();

extern int max_parallel;

extern int asm_noperands ();
extern char *decode_asm_operands ();

extern enum reg_class reg_preferred_class ();

extern rtx get_first_nonparm_insn ();

extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx fconst0_rtx;
extern rtx dconst0_rtx;

extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;

enum tree_code {

  ERROR_MARK,

  IDENTIFIER_NODE,

  OP_IDENTIFIER,

  TREE_LIST,

  VOID_TYPE, 	

  INTEGER_TYPE,

  REAL_TYPE,

  COMPLEX_TYPE,

  ENUMERAL_TYPE,

  BOOLEAN_TYPE,

  CHAR_TYPE,

  POINTER_TYPE,

  OFFSET_TYPE,

  REFERENCE_TYPE,

  METHOD_TYPE,

  FILE_TYPE,

  ARRAY_TYPE,

  SET_TYPE,

  STRING_TYPE,

  RECORD_TYPE,

  UNION_TYPE, 	

  FUNCTION_TYPE,

  LANG_TYPE,

  LABEL_STMT,

  GOTO_STMT,

  RETURN_STMT,

  EXPR_STMT,

  WITH_STMT,

  LET_STMT,

  IF_STMT,

  EXIT_STMT,

  CASE_STMT,

  LOOP_STMT,

  COMPOUND_STMT,

  ASM_STMT,

  INTEGER_CST,

  REAL_CST,

  COMPLEX_CST,

  STRING_CST,

  FUNCTION_DECL,
  LABEL_DECL,
  CONST_DECL,
  TYPE_DECL,
  VAR_DECL,
  PARM_DECL,
  RESULT_DECL,
  FIELD_DECL,

  COMPONENT_REF,

  INDIRECT_REF,

  OFFSET_REF,

  BUFFER_REF,

  ARRAY_REF,

  CONSTRUCTOR,

  COMPOUND_EXPR,

  MODIFY_EXPR,

  INIT_EXPR,

  NEW_EXPR,
  DELETE_EXPR,

  PUSH_EXPR,
  POP_EXPR,

  COND_EXPR,

  CALL_EXPR,

  METHOD_CALL_EXPR,

  WITH_CLEANUP_EXPR,

  PLUS_EXPR,
  MINUS_EXPR,
  MULT_EXPR,

  TRUNC_DIV_EXPR,

  CEIL_DIV_EXPR,

  FLOOR_DIV_EXPR,

  ROUND_DIV_EXPR,

  TRUNC_MOD_EXPR,
  CEIL_MOD_EXPR,
  FLOOR_MOD_EXPR,
  ROUND_MOD_EXPR,

  RDIV_EXPR,

  EXACT_DIV_EXPR,

  FIX_TRUNC_EXPR,
  FIX_CEIL_EXPR,
  FIX_FLOOR_EXPR,
  FIX_ROUND_EXPR,

  FLOAT_EXPR,

  EXPON_EXPR,

  NEGATE_EXPR,

  MIN_EXPR,
  MAX_EXPR,
  ABS_EXPR,
  FFS_EXPR,

  LSHIFT_EXPR,
  RSHIFT_EXPR,
  LROTATE_EXPR,
  RROTATE_EXPR,

  BIT_IOR_EXPR,
  BIT_XOR_EXPR,
  BIT_AND_EXPR,
  BIT_ANDTC_EXPR,
  BIT_NOT_EXPR,

  TRUTH_ANDIF_EXPR,
  TRUTH_ORIF_EXPR,
  TRUTH_AND_EXPR,
  TRUTH_OR_EXPR,
  TRUTH_NOT_EXPR,

  LT_EXPR,
  LE_EXPR,
  GT_EXPR,
  GE_EXPR,
  EQ_EXPR,
  NE_EXPR,

  IN_EXPR,
  SET_LE_EXPR,
  CARD_EXPR,
  RANGE_EXPR,

  CONVERT_EXPR,

  NOP_EXPR,

  SAVE_EXPR,

  RTL_EXPR,

  ADDR_EXPR,

  REFERENCE_EXPR,

  WRAPPER_EXPR,
  ANTI_WRAPPER_EXPR,

  ENTRY_VALUE_EXPR,

  COMPLEX_EXPR,

  CONJ_EXPR,

  REALPART_EXPR,
  IMAGPART_EXPR,

  PREDECREMENT_EXPR,
  PREINCREMENT_EXPR,
  POSTDECREMENT_EXPR,
  POSTINCREMENT_EXPR,

  LAST_AND_UNUSED_TREE_CODE	

};

extern char *tree_code_type[];

extern int tree_code_length[];

enum built_in_function
{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_FSQRT,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,

  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,
};

typedef union tree_node *tree;

struct tree_common
{
  int uid;
  union tree_node *chain;
  union tree_node *type;
  unsigned char code : 8;

  unsigned external_attr : 1;
  unsigned public_attr : 1;
  unsigned static_attr : 1;
  unsigned volatile_attr : 1;
  unsigned packed_attr : 1;
  unsigned readonly_attr : 1;
  unsigned literal_attr : 1;
  unsigned nonlocal_attr : 1;
  unsigned permanent_attr : 1;
  unsigned addressable_attr : 1;
  unsigned regdecl_attr : 1;
  unsigned this_vol_attr : 1;
  unsigned unsigned_attr : 1;
  unsigned asm_written_attr: 1;
  unsigned inline_attr : 1;
  unsigned used_attr : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;

};

struct tree_int_cst
{
  char common[sizeof (struct tree_common)];
  long int_cst_low;
  long int_cst_high;
};

extern double ldexp ();

extern double atof ();

union real_extract
{
  double  d;
  int i[sizeof (double ) / sizeof (int)];
};

double  real_value_from_int_cst ();

struct tree_real_cst
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;	

  double  real_cst;
};

struct tree_string
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;	

  int length;
  char *pointer;
};

struct tree_complex
{
  char common[sizeof (struct tree_common)];
  struct rtx_def *rtl;	

  union tree_node *real;
  union tree_node *imag;
};

struct tree_identifier
{
  char common[sizeof (struct tree_common)];
  int length;
  char *pointer;
};

struct tree_list
{
  char common[sizeof (struct tree_common)];
  union tree_node *purpose;
  union tree_node *value;
};

struct tree_exp
{
  char common[sizeof (struct tree_common)];
  int complexity;
  union tree_node *operands[1];
};

struct tree_type
{
  char common[sizeof (struct tree_common)];
  union tree_node *values;
  union tree_node *sep;
  union tree_node *size;

  enum machine_mode mode : 8;
  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union tree_node *pointer_to;
  union tree_node *reference_to;
  int parse_info;
  int symtab_address;
  union tree_node *name;
  union tree_node *max;
  union tree_node *next_variant;
  union tree_node *main_variant;
  union tree_node *basetypes;
  union tree_node *noncopied_parts;

  struct lang_type *lang_specific;
};

struct tree_decl
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *size;
  enum machine_mode mode : 8;
  unsigned char size_unit;
  unsigned char align;
  unsigned char voffset_unit;
  union tree_node *name;
  union tree_node *context;
  int offset;
  union tree_node *voffset;
  union tree_node *arguments;
  union tree_node *result;
  union tree_node *initial;
  char *print_name;
  char *assembler_name;
  struct rtx_def *rtl;	

  int frame_size;		
  struct rtx_def *saved_insns;	

  int block_symtab_address;

  struct lang_decl *lang_specific;
};

struct tree_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *body;
};

struct tree_if_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *cond, *thenpart, *elsepart;
};

struct tree_bind_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *body, *vars, *supercontext, *bind_size, *type_tags;
  union tree_node *subblocks;
};

struct tree_case_stmt
{
  char common[sizeof (struct tree_common)];
  char *filename;
  int linenum;
  union tree_node *index, *case_list;
};

union tree_node
{
  struct tree_common common;
  struct tree_int_cst int_cst;
  struct tree_real_cst real_cst;
  struct tree_string string;
  struct tree_complex complex;
  struct tree_identifier identifier;
  struct tree_decl decl;
  struct tree_type type;
  struct tree_list list;
  struct tree_exp exp;
  struct tree_stmt stmt;
  struct tree_if_stmt if_stmt;
  struct tree_bind_stmt bind_stmt;
  struct tree_case_stmt case_stmt;
};

struct addr_const
{
  rtx base;
  int offset;
};

struct rtx_const
{
  enum kind { RTX_DOUBLE, RTX_INT } kind : 16;
  enum machine_mode mode : 16;
  union {
    union real_extract du;
    struct addr_const addr;
  } un;
};

static void
decode_rtx_const (mode, x, value)
     enum machine_mode mode;
     rtx x;
     struct rtx_const *value;
{

  {
    int *p = (int *) value;
    int *end = (int *) (value + 1);
    while (p < end)
      *p++ = 0;
  }

  value->kind = RTX_INT;	
  value->mode = mode;

  switch (	((x)->code) )
    {
    case CONST_DOUBLE:
      value->kind = RTX_DOUBLE;
      value->mode = 	((x)->mode) ;
      bcopy (&((x)->fld[ 2].rtint)  , &value->un.du, sizeof value->un.du);
      break;

    case CONST_INT:
      value->un.addr.offset = ((x)->fld[0].rtint) ;
      break;

    case SYMBOL_REF:
      value->un.addr.base = x;
      break;

    case LABEL_REF:
      value->un.addr.base = x;
      break;

    case CONST:
      x = ((x)->fld[ 0].rtx) ;
      if (	((x)->code)  == PLUS)
	{
	  value->un.addr.base = ((((x)->fld[ 0].rtx) )->fld[ 0].rtx) ;
	  if (	((((x)->fld[ 1].rtx) )->code)  != CONST_INT)
	    abort ();
	  value->un.addr.offset = ((((x)->fld[ 1].rtx) )->fld[0].rtint) ;
	}
      else if (	((x)->code)  == MINUS)
	{
	  value->un.addr.base = ((x)->fld[ 0].rtx) ;
	  if (	((((x)->fld[ 1].rtx) )->code)  != CONST_INT)
	    abort ();
	  value->un.addr.offset = - ((((x)->fld[ 1].rtx) )->fld[0].rtint) ;
	}
      else
	abort ();
      break;

    default:
      abort ();
    }

  if (value->kind == RTX_INT && value->un.addr.base != 0)
    switch (	((value->un.addr.base)->code) )
      {
      case SYMBOL_REF:
      case LABEL_REF:
	

	value->un.addr.base = ((value->un.addr.base)->fld[ 0].rtx) ;
      }
}

foo (a)
{
  bar (a);
  bar (a);
}


void
Rotate (float angle)
{
    float mag = (angle < 0) ? -angle : angle;
}

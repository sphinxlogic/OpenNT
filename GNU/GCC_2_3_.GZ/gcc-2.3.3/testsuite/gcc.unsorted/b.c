main ()
{
  *(short *) 25 = 123;
}

BUG2 (p) char *p;
{
  int a = 0;
  if (*p == a)
    return 0;
  else
    return 1;
}

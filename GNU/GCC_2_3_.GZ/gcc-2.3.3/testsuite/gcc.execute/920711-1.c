f(a){return (--a > 0);}
main(){if(f(0x80000000)==0)abort();exit(0);}

f(short a,short b){return a/b;}
main(){if(f(-32768,-1)!=32768)abort();else exit(0);}

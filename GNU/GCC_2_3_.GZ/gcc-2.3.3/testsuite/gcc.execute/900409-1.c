f1(a){return a&0xff000000;}
f2 (a){return a&~0xff000000;}
f3(a){return a&0x000000ff;}
f4(a){return a&~0x000000ff;}
f5(a){return a&0x0000ffff;}
f6(a){return a&~0x0000ffff;}

main ()
{
  int a = 0x89ABCDEF;

  if (f1(a)!=0x89000000||
      f2(a)!=0x00ABCDEF||
      f3(a)!=0x000000EF||
      f4(a)!=0x89ABCD00||
      f5(a)!=0x0000CDEF||
      f6(a)!=0x89AB0000)
    abort();
  exit(0);
}

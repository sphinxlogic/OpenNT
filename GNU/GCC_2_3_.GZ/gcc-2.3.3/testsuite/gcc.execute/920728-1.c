typedef struct {int dims[0]; } *A;

f(unsigned obj)
{  
  unsigned char y = obj >> 24;
  y &= ~4;

  if ((y==0)||(y!=251  ))
    abort();

  if(((int)obj&7)!=7)return;

  REST_OF_CODE_JUST_HERE_TO_TRIGGER_THE_BUG:

  {
    unsigned char t = obj >> 24;
    if (!(t==0)&&(t<=0x03))
      return 0;
    return ((A)(obj&0x00FFFFFF))->dims[1];
  }
}

g(){return 0xff000000;}
main (){int x;f(g());exit(0);}

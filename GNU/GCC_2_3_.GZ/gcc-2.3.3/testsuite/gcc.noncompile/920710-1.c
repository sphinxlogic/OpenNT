struct x{int a;}y={{{0}}};

x(){register*a asm("fr1");int*v[1]={a};}

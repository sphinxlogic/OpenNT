struct{int c;}v;
static short i=((char*)&(v.c)-(char*)&v);
this line is here just to make this fit into the noncompile suite.

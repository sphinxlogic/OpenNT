void a (void x) {}

union
{
int f;
int g;
}u={};

f(void a,...){}

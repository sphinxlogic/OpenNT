/*
   Copyright (c) 1991 - 1993 Heinz W. Werntges.  All rights reserved.
   Distributed by Free Software Foundation, Inc.

This file is part of HP2xx.

HP2xx is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY.  No author or distributor accepts responsibility
to anyone for the consequences of using it or for whether it serves any
particular purpose or works at all, unless he says so in writing.  Refer
to the GNU General Public License, Version 2 or later, for full details.

Everyone is granted permission to copy, modify and redistribute
HP2xx, but only under the conditions described in the GNU General Public
License.  A copy of this license is supposed to have been
given to you along with HP2xx so you can know your rights and
responsibilities.  It should be in a file named COPYING.  Among other
things, the copyright notice and this notice must be preserved on all
copies.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
*/

/** to_pic.c: PIC (ATARI "32k" bitmap) formatter part of project "hp2xx"
 **
 ** 91/08/28  V 1.00  HWW  Originating
 ** 91/09/08  V 1.01  HWW  Bug fixed: Repeated block columns
 ** 91/10/09  V 1.02  HWW  ANSI-C definitions; new ATARI file name convention
 ** 91/10/16  V 1.03b HWW  STAD mode (output file packing) added
 ** 91/10/21  V 1.03d HWW  Plain "pic", packing done by pic2pac; VAX_C active
 ** 91/03/01  V 1.03e NM   Bug fixed: numbering of files was incorrect
 ** 91/05/19  V 1.03f HWW  Abort if color mode
 **
 **	      NOTE:   This code is not part of the supported modules
 **		      of hp2xx. Include it if needed only.
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef	TURBO_C
  #include <io.h>
#endif
#include "bresnham.h"
#include "hp2xx.h"



#define ATARI_XRES	640	/* MUST be multiple of 8	*/
#define ATARI_YRES	400
#define BYTES_PER_LINE	(ATARI_XRES>>3)




int	Init_PIC_files (char *basename, FILE **fd, int nb, int nr, int yb)
{
#define	FNAME_LEN	80
char	fname[FNAME_LEN], ext[8];
int	i, n, yb_tot;
#ifdef VAX
int	hd;
#endif


  yb_tot = 1 + (nr - 1) / ATARI_YRES;    /* Total # of y blocks */


  for (i=0; nb > 0; i++, nb -= BYTES_PER_LINE)
  {
	if (fd[i])
	{
		fclose (fd[i]);
		fd[i] = NULL;
	}

	n = yb + i * yb_tot;
	if (n > 99)
	{
		fprintf (stderr,"ERROR: Too many PIC files per column!\n");
		for (; i > -1; i--)
			if (fd[i])
			{
				fclose (fd[i]);
				fd[i] = NULL;
			}
		return ERROR;
	}

	sprintf(ext,"%02d.pic", n);

	strcpy (fname, basename);
	strncat (fname, ext, FNAME_LEN - strlen(basename) - 1);

#ifdef VAX
	if ((fd[i] = fopen(fname, WRITE_BIN, "rfm=var","mrs=512")) == NULL)
	{
#else
	if ((fd[i] = fopen(fname, WRITE_BIN)) == NULL)
	{
#endif
		perror ("hp2xx -- opening PIC file(s)");
		return ERROR;
	}
  }
  return 0;
}





void	PicBuf_to_PIC (PicBuf *picbuf, PAR *p)
{
#define	N_BLOCKS 10

FILE	*fd[N_BLOCKS];
int	row_c, i, nb, nr, yb;

  if (picbuf->depth > 1)
  {
	fprintf(stderr, "\nPIC mode does not support colors yet -- sorry\n");
	free_PicBuf (picbuf, p->swapfile);
	exit (ERROR);
  }

  if (picbuf->nb > (ATARI_XRES * N_BLOCKS) / 8)
  {
	fprintf (stderr, "hp2xx -- Too many PIC files per row");
	free_PicBuf (picbuf, p->swapfile);
	exit (ERROR);
  }

  if (! p->quiet)
	fprintf(stderr, "\nWriting PIC output: %d rows of %d bytes\n",
		picbuf->nr, picbuf->nb);

  if (! *p->outfile)
	p->outfile = "bitmap";		/* Default name	*/

  for (i=0, nb = picbuf->nb; nb > 0; i++, nb -= BYTES_PER_LINE)
	fd[i] = NULL;


  /* Backward since highest index is lowest line on screen! */

  for (yb=nr=0, row_c = picbuf->nr - 1; row_c >= 0; nr++, row_c--)
  {
	if (nr % ATARI_YRES == 0)
	{
		if (Init_PIC_files (p->outfile, fd,
				picbuf->nb, picbuf->nr, yb))
		{
			free_PicBuf (picbuf, p->swapfile);
			exit (ERROR);
		}
		yb++;
	}
	if ((!p->quiet) && (row_c % 10 == 0))
		  /* For the impatients among us ...	*/
		putc('.',stderr);
	RowBuf_to_PIC (get_RowBuf(picbuf, row_c), picbuf->nb, fd);
  }

  get_RowBuf(picbuf, 0);		/* Use row 0 for padding */
  for (i=0; i < picbuf->nb; i++)	/* Clear it		 */
	picbuf->row[0].buf[i] = '\0';

  while (nr % ATARI_YRES != 0)
  {
	RowBuf_to_PIC (&picbuf->row[0], picbuf->nb, fd);
	nr++;
  }


  if (!p->quiet)
	fputc ('\n', stderr);

  for (i=0, nb = picbuf->nb; nb > 0; i++, nb -= BYTES_PER_LINE)
  {
	fclose (fd[i]);
	fd[i] = NULL;
  }
}




void	RowBuf_to_PIC (RowBuf *row, int nb, FILE **fd)
{
int	i,j, n_pad=0, n_wr=BYTES_PER_LINE;

/* VAX peculiarity: Writing one big object is faster than many smaller */

  if (nb % BYTES_PER_LINE)	/* padding required	*/
	n_pad = (nb/BYTES_PER_LINE + 1)*BYTES_PER_LINE - nb;

  for (i=0; nb > 0; i++, nb -= n_wr)
	fwrite ((char *) &row->buf[i*BYTES_PER_LINE],
		 n_wr=MIN(nb,BYTES_PER_LINE), 1, fd[i]);

  for (i--, j=0; j < n_pad; j++)/* Fill last block with zero	*/
	fputc ('\0', fd[i]);
}

